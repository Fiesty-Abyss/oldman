<template>
  <div>
    <LoginPage v-if="!isLogin" @login-success="isLogin = true" />

    <div v-else :class="['app-page', theme]">
      <TopBar @logout="logout" />

      <main class="main">
        <CategoryBar
          :categories="categories"
          :current-category="currentCategory"
          @change-category="currentCategory = $event"
          @add-category="addCategory"
          @delete-category="deleteCategory"
        />

        <section class="content">
          <div class="hero">
            <div>
              <h2>发现值得一看的电影</h2>
              <p>这里整理了不同类型的经典影片，你可以浏览分类、搜索导演演员，也可以添加自己的推荐。</p>
            </div>

            <div class="hero-badges">
              <el-badge :value="movies.length" class="item" type="primary">
                <el-button>电影</el-button>
              </el-badge>
              <el-badge :value="commentTotal" class="item" type="warning">
                <el-button>评论</el-button>
              </el-badge>
            </div>
          </div>

          <div class="tools">
            <el-input v-model="keyword" placeholder="搜索电影、导演或演员" clearable>
              <i slot="prefix" class="el-input__icon el-icon-search"></i>
            </el-input>

            <el-button type="primary" @click="openAddForm">
              {{ showForm ? '收起添加' : '添加电影' }}
            </el-button>
          </div>

          <MovieForm
            v-if="showForm"
            :categories="categories"
            :edit-movie="editMovie"
            :edit-id="editId"
            :current-category="currentCategory"
            :image-map="imageMap"
            @save="saveMovie"
            @cancel="closeForm"
          />

          <div class="section-title">
            <h2>{{ currentCategory }}</h2>
            <span>共 {{ filteredMovies.length }} 部电影</span>
          </div>

          <div class="movie-list">
            <MovieCard
              v-for="movie in filteredMovies"
              :key="movie.id"
              :movie="movie"
              :image-map="imageMap"
              @edit="openDetail"
              @delete="deleteMovie"
              @open-detail="openDetail"
            />
          </div>

          <el-empty v-if="filteredMovies.length === 0" description="当前没有找到相关电影" />
        </section>
      </main>

      <div class="theme-switch">
        <span>{{ theme === 'dark' ? '深色' : '浅色' }}</span>
        <el-switch
          v-model="isDark"
          active-text="深"
          inactive-text="浅"
          @change="changeTheme"
        />
      </div>

      <MovieDetail
        :visible="detailVisible"
        :movie="selectedMovie"
        :image-map="imageMap"
        :categories="categories"
        @close="detailVisible = false"
        @comment="addComment"
        @reply="addReply"
        @update-movie="updateMovie"
        @delete-comment="deleteComment"
      />
    </div>
  </div>
</template>

<script>
import { Message } from 'element-ui'
import LoginPage from './components/LoginPage.vue'
import TopBar from './components/TopBar.vue'
import CategoryBar from './components/CategoryBar.vue'
import MovieForm from './components/MovieForm.vue'
import MovieCard from './components/MovieCard.vue'
import MovieDetail from './components/MovieDetail.vue'
import { defaultCategories, defaultMovies } from './data/movies'

const imageContext = require.context('./assets/images', false, /\.(png|jpg|jpeg)$/)
const imageMap = {}
imageContext.keys().forEach(key => {
  imageMap['./assets/images/' + key.replace('./', '')] = imageContext(key)
})

export default {
  name: 'App',
  components: {
    LoginPage,
    TopBar,
    CategoryBar,
    MovieForm,
    MovieCard,
    MovieDetail
  },
  data() {
    return {
      imageMap,
      isLogin: false,
      isDark: false,
      theme: 'light',
      categories: [].concat(defaultCategories),
      movies: defaultMovies.map(item => ({
        ...item,
        fenlei: this.normalizeCategory(item.fenlei),
        pinglun: item.pinglun.map(comment => ({
          ...comment,
          huifuList: comment.huifuList || []
        }))
      })),
      currentCategory: '全部电影',
      keyword: '',
      showForm: false,
      editId: null,
      editMovie: null,
      detailVisible: false,
      selectedMovie: null
    }
  },
  computed: {
    filteredMovies() {
      const word = this.keyword.trim().toLowerCase()
      return this.movies.filter(item => {
        const movieCategories = this.normalizeCategory(item.fenlei)
        const matchCategory = this.currentCategory === '全部电影' || movieCategories.includes(this.currentCategory)
        const matchWord = !word ||
          item.mingcheng.toLowerCase().includes(word) ||
          item.daoyan.toLowerCase().includes(word) ||
          item.zhuyan.toLowerCase().includes(word)
        return matchCategory && matchWord
      })
    },
    commentTotal() {
      return this.movies.reduce((sum, item) => sum + item.pinglun.length, 0)
    }
  },
  methods: {
    normalizeCategory(value) {
      if (Array.isArray(value)) return value
      if (!value) return []
      return [value]
    },
    logout() {
      this.isLogin = false
    },
    changeTheme(value) {
      this.theme = value ? 'dark' : 'light'
    },
    addCategory(name) {
      if (this.categories.includes(name)) {
        Message.warning('这个分类已经存在')
        return
      }
      this.categories.push(name)
      this.currentCategory = name
      Message.success('分类添加成功')
    },
    deleteCategory(name) {
      this.categories = this.categories.filter(item => item !== name)
      this.movies = this.movies.map(movie => ({
        ...movie,
        fenlei: this.normalizeCategory(movie.fenlei).filter(item => item !== name)
      }))
      if (this.currentCategory === name) {
        this.currentCategory = '全部电影'
      }
      Message.success('分类已删除，电影仍保留在全部电影中')
    },
    openAddForm() {
      this.showForm = !this.showForm
      this.editId = null
      this.editMovie = null
    },
    closeForm() {
      this.showForm = false
      this.editId = null
      this.editMovie = null
    },
    saveMovie(data) {
      if (this.editId) {
        this.updateMovie(this.editId, data)
        Message.success('电影修改成功')
      } else {
        this.movies.push({
          id: Date.now(),
          ...data,
          fenlei: this.normalizeCategory(data.fenlei).slice(0, 3),
          pingfen: Number(data.pingfen || 0).toFixed(1),
          pinglun: []
        })
        Message.success('电影添加成功')
      }
      this.currentCategory = data.fenlei && data.fenlei.length ? data.fenlei[0] : '全部电影'
      this.closeForm()
    },
    deleteMovie(id) {
      const result = confirm('确定删除这部电影吗？')
      if (result) {
        this.movies = this.movies.filter(item => item.id !== id)
        if (this.selectedMovie && this.selectedMovie.id === id) {
          this.detailVisible = false
          this.selectedMovie = null
        }
        Message.success('删除成功')
      }
    },
    openDetail(movie) {
      this.selectedMovie = movie
      this.detailVisible = true
    },
    addComment(movieId, text) {
      const movie = this.movies.find(item => item.id === movieId)
      if (!movie) return
      movie.pinglun.push({
        id: Date.now(),
        neirong: text,
        zan: 0,
        huifu: 0,
        huifuList: []
      })
      Message.success('评论发表成功')
    },
    deleteComment(movieId, commentId) {
      const movie = this.movies.find(item => item.id === movieId)
      if (!movie) return
      movie.pinglun = movie.pinglun.filter(item => item.id !== commentId)
      Message.success('评论已删除')
    },
    addReply(movieId, commentId, text) {
      const movie = this.movies.find(item => item.id === movieId)
      if (!movie) return
      const comment = movie.pinglun.find(item => item.id === commentId)
      if (!comment) return
      if (!comment.huifuList) {
        this.$set(comment, 'huifuList', [])
      }
      comment.huifuList.push({
        id: Date.now(),
        neirong: text
      })
      Message.success('回复成功')
    },
    updateMovie(movieId, data) {
      const index = this.movies.findIndex(item => item.id === movieId)
      if (index === -1) return
      const newMovie = {
        ...this.movies[index],
        ...data,
        fenlei: this.normalizeCategory(data.fenlei).slice(0, 3),
        pingfen: Number(data.pingfen || 0).toFixed(1)
      }
      this.$set(this.movies, index, newMovie)
      this.selectedMovie = newMovie
      this.currentCategory = newMovie.fenlei.length ? newMovie.fenlei[0] : '全部电影'
      Message.success('电影信息已更新')
    }
  }
}
</script>

<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: "Microsoft YaHei", Arial, sans-serif;
}

button {
  cursor: pointer;
}

.app-page {
  min-height: 100vh;
  background: var(--page-bg);
  color: var(--text-main);
  transition: 0.25s;
}

.light {
  --page-bg: #f5f6f8;
  --card-bg: #ffffff;
  --soft-bg: #f1f2f4;
  --text-main: #222222;
  --text-sub: #666666;
  --border: #eeeeee;
  --primary: #222222;
  --top-bg: #222222;
  --top-text: #ffffff;
  --top-sub: #bbbbbb;
  --shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
}

.dark {
  --page-bg: #15171c;
  --card-bg: #20232a;
  --soft-bg: #2b2f38;
  --text-main: #f1f1f1;
  --text-sub: #b8bdc7;
  --border: #343946;
  --primary: #409eff;
  --top-bg: #111318;
  --top-text: #ffffff;
  --top-sub: #aeb4c0;
  --shadow: 0 8px 24px rgba(0, 0, 0, 0.24);
}

.main {
  display: flex;
  gap: 24px;
  padding: 26px 42px 80px;
}

.content {
  flex: 1;
}

.hero {
  background: var(--card-bg);
  color: var(--text-main);
  padding: 26px;
  border-radius: 18px;
  box-shadow: var(--shadow);
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
  gap: 20px;
}

.hero h2 {
  margin: 0 0 10px;
  font-size: 28px;
}

.hero p {
  margin: 0;
  color: var(--text-sub);
  line-height: 1.8;
}

.hero-badges {
  display: flex;
  align-items: center;
  white-space: nowrap;
}

.item {
  margin-right: 34px;
}

.tools {
  display: flex;
  gap: 14px;
  margin-bottom: 18px;
}

.tools .el-input {
  flex: 1;
}

.section-title {
  display: flex;
  align-items: end;
  justify-content: space-between;
  margin: 8px 0 18px;
}

.section-title h2 {
  margin: 0;
}

.section-title span {
  color: var(--text-sub);
}

.movie-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(540px, 1fr));
  gap: 20px;
}

.theme-switch {
  position: fixed;
  left: 24px;
  bottom: 22px;
  background: var(--card-bg);
  color: var(--text-main);
  padding: 12px 16px;
  border-radius: 999px;
  box-shadow: var(--shadow);
  display: flex;
  align-items: center;
  gap: 12px;
  z-index: 20;
}

@media (max-width: 900px) {
  .main {
    flex-direction: column;
    padding: 20px 20px 90px;
  }

  .movie-list {
    grid-template-columns: 1fr;
  }

  .hero {
    flex-direction: column;
  }
}
</style>
