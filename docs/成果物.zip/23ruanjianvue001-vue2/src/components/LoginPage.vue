<template>
  <div class="login-page">
    <div class="login-box">
      <h1>电影分享</h1>
      <p>登录后收藏、分享和管理你喜欢的电影</p>

      <el-tabs v-model="mode" stretch>
        <el-tab-pane label="登录" name="login" />
        <el-tab-pane label="注册" name="register" />
      </el-tabs>

      <el-input v-model="form.username" placeholder="请输入账号" size="large" />
      <el-input v-model="form.password" type="password" placeholder="请输入密码" size="large" show-password />

      <el-button type="primary" size="large" class="main-btn" @click="handleAccount">
        {{ mode === 'login' ? '登录系统' : '注册账号' }}
      </el-button>

      <div class="message">{{ message }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LoginPage',
  data() {
    return {
      mode: 'login',
      message: '',
      form: {
        username: '',
        password: ''
      }
    }
  },
  methods: {
    handleAccount() {
      if (!this.form.username || !this.form.password) {
        this.message = '账号和密码不能为空'
        return
      }

      if (this.mode === 'register') {
        localStorage.setItem('movieUser', JSON.stringify({
          username: this.form.username,
          password: this.form.password
        }))
        this.message = '注册成功，请登录'
        this.mode = 'login'
        return
      }

      const user = JSON.parse(localStorage.getItem('movieUser') || '{}')
      if (user.username === this.form.username && user.password === this.form.password) {
        this.message = ''
        this.$emit('login-success')
      } else {
        this.message = '账号或密码错误，未注册可以先注册'
      }
    }
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #252a34, #6e7685);
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-box {
  width: 390px;
  padding: 34px;
  background: #fff;
  border-radius: 18px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
}

.login-box h1 {
  margin: 0;
  font-size: 30px;
  color: #222;
}

.login-box p {
  margin: 10px 0 20px;
  color: #777;
}

.el-input {
  margin-bottom: 14px;
}

.main-btn {
  width: 100%;
}

.message {
  height: 22px;
  margin-top: 14px;
  color: #c0392b;
  font-size: 14px;
}
</style>
