<template>
  <header class="top-bar">
    <div>
      <h1>电影分享系统</h1>
      <span>发现电影 · 分享感受 · 记录热爱</span>
    </div>

    <div class="right">
      <el-dropdown trigger="click">
        <span class="dropdown-link">
          消息中心 <i class="el-icon-arrow-down"></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>
            评论
            <el-badge class="mark" :value="12" />
          </el-dropdown-item>
          <el-dropdown-item>
            回复
            <el-badge class="mark" :value="3" />
          </el-dropdown-item>
          <el-dropdown-item>
            点赞
            <el-badge class="mark" :value="8" type="warning" />
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

      <el-button plain @click="$emit('logout')">退出登录</el-button>
    </div>
  </header>
</template>

<script>
export default {
  name: 'TopBar'
}
</script>

<style scoped>
.top-bar {
  height: 78px;
  padding: 0 42px;
  background: var(--top-bg);
  color: var(--top-text);
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.top-bar h1 {
  margin: 0;
  font-size: 26px;
}

.top-bar span {
  color: var(--top-sub);
  font-size: 14px;
}

.right {
  display: flex;
  align-items: center;
  gap: 22px;
}

.dropdown-link {
  display: flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  color: var(--top-text);
}

.mark {
  margin-left: 24px;
}
</style>
