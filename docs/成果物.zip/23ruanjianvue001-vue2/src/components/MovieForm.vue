<template>
  <div class="movie-form">
    <h3>{{ editId ? '修改电影' : '添加电影' }}</h3>

    <el-row :gutter="14">
      <el-col :span="12">
        <el-input v-model="form.mingcheng" placeholder="电影名称" />
      </el-col>
      <el-col :span="12">
        <el-select
          v-model="form.fenlei"
          multiple
          :multiple-limit="3"
          placeholder="选择分类，最多三个"
          class="full"
        >
          <el-option v-for="item in categories" :key="item" :label="item" :value="item" />
        </el-select>
      </el-col>
    </el-row>

    <el-row :gutter="14">
      <el-col :span="12">
        <el-input v-model="form.daoyan" placeholder="导演" />
      </el-col>
      <el-col :span="12">
        <el-input v-model="form.zhuyan" placeholder="演员，多个演员用逗号隔开" />
      </el-col>
    </el-row>

    <el-row :gutter="14">
      <el-col :span="12">
        <el-input v-model="form.nianfen" placeholder="年份" />
      </el-col>
      <el-col :span="12">
        <el-input-number
          v-model="form.pingfen"
          :min="0"
          :max="10"
          :precision="1"
          :step="0.1"
          class="full"
        />
      </el-col>
    </el-row>

    <div class="upload-area">
      <div class="upload-title">电影海报</div>

      <el-upload
        class="poster-upload"
        action="#"
        :auto-upload="false"
        :show-file-list="false"
        accept="image/*"
        :on-change="handlePosterChange"
      >
        <div class="poster-box">
          <img v-if="posterPreview" :src="posterPreview" />
          <div v-else class="poster-empty">
            <i class="el-icon-plus"></i>
            <span>点击上传海报</span>
          </div>
        </div>
      </el-upload>

      <p class="upload-tip">建议使用 jpg 或 png 图片，比例接近电影海报会更好看。</p>
    </div>

    <el-input
      v-model="form.jianjie"
      type="textarea"
      :rows="4"
      placeholder="电影简介"
    />

    <div class="buttons">
      <el-button type="primary" @click="saveMovie">
        {{ editId ? '保存修改' : '确认添加' }}
      </el-button>
      <el-button @click="$emit('cancel')">取消</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MovieForm',
  props: {
    categories: {
      type: Array,
      default: function () {
        return []
      }
    },
    editMovie: {
      type: Object,
      default: null
    },
    editId: {
      type: Number,
      default: null
    },
    currentCategory: {
      type: String,
      default: '全部电影'
    },
    imageMap: {
      type: Object,
      default: function () {
        return {}
      }
    }
  },
  data() {
    return {
      posterPreview: '',
      form: {
        mingcheng: '',
        fenlei: [],
        daoyan: '',
        zhuyan: '',
        nianfen: '',
        pingfen: 0,
        jianjie: '',
        haibao: '',
        haibaoUrl: ''
      }
    }
  },
  watch: {
    editMovie: {
      immediate: true,
      handler(movie) {
        if (movie) {
          this.form = {
            mingcheng: movie.mingcheng,
            fenlei: this.normalizeCategory(movie.fenlei),
            daoyan: movie.daoyan,
            zhuyan: movie.zhuyan,
            nianfen: movie.nianfen,
            pingfen: Number(movie.pingfen || 0),
            jianjie: movie.jianjie,
            haibao: movie.haibao || '',
            haibaoUrl: movie.haibaoUrl || ''
          }
          this.posterPreview = movie.haibaoUrl || this.getLocalPoster(movie.haibao)
        } else {
          this.form = {
            mingcheng: '',
            fenlei: this.getDefaultCategory(),
            daoyan: '',
            zhuyan: '',
            nianfen: '',
            pingfen: 0,
            jianjie: '',
            haibao: '',
            haibaoUrl: ''
          }
          this.posterPreview = ''
        }
      }
    }
  },
  methods: {
    normalizeCategory(value) {
      if (Array.isArray(value)) return value
      if (!value) return []
      return [value]
    },
    getDefaultCategory() {
      if (this.currentCategory && this.currentCategory !== '全部电影' && this.currentCategory !== '未分类') {
        return [this.currentCategory]
      }
      return this.categories.length ? [this.categories[0]] : []
    },
    getLocalPoster(name) {
      if (!name || !this.imageMap) return ''
      return this.imageMap['./assets/images/' + name] || ''
    },
    handlePosterChange(file) {
      if (!file.raw) return
      const url = URL.createObjectURL(file.raw)
      this.posterPreview = url
      this.form.haibaoUrl = url
      this.form.haibao = file.name
    },
    saveMovie() {
      if (!this.form.mingcheng) {
        alert('电影名称不能为空')
        return
      }
      this.$emit('save', {
        ...this.form,
        fenlei: this.form.fenlei.slice(0, 3),
        pingfen: Number(this.form.pingfen || 0).toFixed(1)
      })
    }
  }
}
</script>

<style scoped>
.movie-form {
  background: var(--card-bg);
  color: var(--text-main);
  padding: 20px;
  border-radius: 16px;
  margin-bottom: 22px;
  box-shadow: var(--shadow);
}

.movie-form h3 {
  margin-top: 0;
}

.el-row {
  margin-bottom: 14px;
}

.full {
  width: 100%;
}

.upload-area {
  margin-bottom: 14px;
}

.upload-title {
  margin-bottom: 10px;
  font-weight: 600;
}

.poster-upload {
  width: fit-content;
}

.poster-box {
  width: 150px;
  height: 210px;
  border: 1px dashed #999;
  border-radius: 12px;
  overflow: hidden;
  background: var(--soft-bg);
  display: flex;
  align-items: center;
  justify-content: center;
}

.poster-box img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.poster-empty {
  color: var(--text-sub);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}

.poster-empty .el-icon-plus {
  font-size: 28px;
}

.upload-tip {
  margin: 8px 0 0;
  color: var(--text-sub);
  font-size: 13px;
}

.buttons {
  display: flex;
  gap: 10px;
  margin-top: 14px;
}
</style>
