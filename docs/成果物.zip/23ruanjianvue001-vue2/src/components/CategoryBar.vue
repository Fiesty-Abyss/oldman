<template>
  <aside class="category-bar">
    <h3>电影目录</h3>

    <div
      class="category-item"
      :class="{ active: currentCategory === '全部电影' }"
      @click="$emit('change-category', '全部电影')"
    >
      <span>全部电影</span>
    </div>

    <div
      v-for="item in categories"
      :key="item"
      class="category-item"
      :class="{ active: currentCategory === item }"
      @click="$emit('change-category', item)"
    >
      <span>{{ item }}</span>

      <el-popconfirm
        title="删除分类后，电影不会删除，只会从该分类中移除。确定吗？"
        confirm-button-text="确定"
        cancel-button-text="取消"
        @confirm="$emit('delete-category', item)"
      >
        <el-button
          slot="reference"
          class="delete-btn"
          type="text"
          size="small"
          @click.stop
        >
          删除
        </el-button>
      </el-popconfirm>
    </div>

    <div class="add-category">
      <el-input v-model="newCategory" placeholder="新增分类" size="small" />
      <el-button type="primary" size="small" @click="addCategory">添加分类</el-button>
    </div>
  </aside>
</template>

<script>
export default {
  name: 'CategoryBar',
  props: {
    categories: {
      type: Array,
      default: function () {
        return []
      }
    },
    currentCategory: {
      type: String,
      default: '全部电影'
    }
  },
  data() {
    return {
      newCategory: ''
    }
  },
  methods: {
    addCategory() {
      const name = this.newCategory.trim()
      if (!name) return
      this.$emit('add-category', name)
      this.newCategory = ''
    }
  }
}
</script>

<style scoped>
.category-bar {
  width: 230px;
  background: var(--card-bg);
  color: var(--text-main);
  padding: 20px;
  border-radius: 16px;
  height: fit-content;
  box-shadow: var(--shadow);
}

.category-bar h3 {
  margin: 0 0 16px;
}

.category-item {
  width: 100%;
  margin-bottom: 10px;
  padding: 11px;
  border-radius: 10px;
  background: var(--soft-bg);
  color: var(--text-main);
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
}

.category-item.active {
  background: var(--primary);
  color: white;
}

.delete-btn {
  opacity: 0;
  color: #c0392b;
  transition: 0.2s;
}

.category-item:hover .delete-btn {
  opacity: 1;
}

.category-item.active .delete-btn {
  color: white;
}

.add-category {
  border-top: 1px solid var(--border);
  margin-top: 14px;
  padding-top: 14px;
}

.add-category .el-button {
  width: 100%;
  margin-top: 10px;
}
</style>
