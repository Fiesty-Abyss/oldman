<template>
  <el-dialog
    :visible="visible"
    width="900px"
    :title="movie ? movie.mingcheng : '电影详情'"
    @close="closeDialog"
  >
    <div v-if="movie" class="detail">
      <img class="poster" :src="posterSrc" @error="handleError" />

      <div class="content">
        <template v-if="!editMode">
          <div class="headline">
            <h2>{{ movie.mingcheng }}</h2>

            <div class="score-box">
              <el-rate
                :value="Number(movie.pingfen)"
                :max="10"
                disabled
                text-color="#ff9900"
              />
              <span>{{ movie.pingfen }} 分</span>
            </div>
          </div>

          <div class="tags">
            <el-tag v-for="item in showCategories" :key="item">
              {{ item }}
            </el-tag>
            <el-tag type="info">{{ movie.nianfen }}</el-tag>
            <el-tag type="warning">评分 {{ movie.pingfen }} / 10</el-tag>
          </div>

          <p class="line">
            <i class="el-icon-video-camera"></i>
            导演：{{ movie.daoyan }}
          </p>

          <p class="line">
            <i class="el-icon-user"></i>
            演员：{{ movie.zhuyan }}
          </p>

          <p class="intro">{{ movie.jianjie }}</p>

          <div class="detail-actions">
            <el-button type="primary" @click="openEdit">编辑电影信息</el-button>
          </div>
        </template>

        <template v-else>
          <div class="edit-panel">
            <h3>编辑电影信息</h3>

            <el-row :gutter="12">
              <el-col :span="12">
                <el-input v-model="editForm.mingcheng" placeholder="电影名称" />
              </el-col>
              <el-col :span="12">
                <el-select
                  v-model="editForm.fenlei"
                  multiple
                  :multiple-limit="3"
                  class="full"
                  placeholder="分类，最多三个"
                >
                  <el-option
                    v-for="item in categories"
                    :key="item"
                    :label="item"
                    :value="item"
                  />
                </el-select>
              </el-col>
            </el-row>

            <el-row :gutter="12">
              <el-col :span="12">
                <el-input v-model="editForm.daoyan" placeholder="导演" />
              </el-col>
              <el-col :span="12">
                <el-input v-model="editForm.zhuyan" placeholder="演员" />
              </el-col>
            </el-row>

            <el-row :gutter="12">
              <el-col :span="12">
                <el-input v-model="editForm.nianfen" placeholder="年份" />
              </el-col>
              <el-col :span="12">
                <el-input-number
                  v-model="editForm.pingfen"
                  :min="0"
                  :max="10"
                  :precision="1"
                  :step="0.1"
                  class="full"
                />
              </el-col>
            </el-row>

            <div class="upload-area">
              <el-upload
                action="#"
                :auto-upload="false"
                :show-file-list="false"
                accept="image/*"
                :on-change="handlePosterChange"
              >
                <el-button>重新上传海报</el-button>
              </el-upload>
              <span class="upload-tip">不上传则保留原海报</span>
            </div>

            <el-input
              v-model="editForm.jianjie"
              type="textarea"
              :rows="4"
              placeholder="电影简介"
            />

            <div class="edit-buttons">
              <el-button type="primary" @click="saveEdit">保存修改</el-button>
              <el-button @click="editMode = false">取消</el-button>
            </div>
          </div>
        </template>

        <div class="comment-title">
          <h3>影迷评论</h3>

          <el-dropdown trigger="click">
            <span class="dropdown-link">
              查看互动 <i class="el-icon-arrow-down"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                评论
                <el-badge class="mark" :value="movie.pinglun.length" />
              </el-dropdown-item>
              <el-dropdown-item>
                回复
                <el-badge class="mark" :value="replyTotal" type="warning" />
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>

        <div class="comment-list">
          <div v-for="item in movie.pinglun" :key="item.id" class="comment">
            <div class="comment-main">
              <el-avatar :size="30">
                <i class="el-icon-user-solid"></i>
              </el-avatar>

              <div class="comment-body">
                <p>{{ item.neirong }}</p>

                <div class="comment-actions">
                  <el-button size="small" type="text" @click="item.zan++">点赞 {{ item.zan }}</el-button>
                  <el-button size="small" type="text" @click="toggleReply(item.id)">
                    回复 {{ getReplyCount(item) }}
                  </el-button>

                  <el-popconfirm
                    title="确定删除这条评论吗？"
                    confirm-button-text="删除"
                    cancel-button-text="取消"
                    @confirm="$emit('delete-comment', movie.id, item.id)"
                  >
                    <el-button slot="reference" size="small" type="text" class="danger-btn">删除</el-button>
                  </el-popconfirm>
                </div>

                <div v-if="item.huifuList && item.huifuList.length" class="reply-list">
                  <div v-for="reply in item.huifuList" :key="reply.id" class="reply-item">
                    <i class="el-icon-chat-dot-round"></i>
                    <span>{{ reply.neirong }}</span>
                  </div>
                </div>

                <div v-if="replyingId === item.id" class="reply-box">
                  <el-input
                    v-model="replyText"
                    size="small"
                    placeholder="写一句回复"
                    clearable
                  />
                  <el-button size="small" type="primary" @click="sendReply(item.id)">
                    回复
                  </el-button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="publish">
          <el-input v-model="commentText" placeholder="写下你的观影感受" clearable />
          <el-button type="primary" @click="addComment">发表</el-button>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script>
export default {
  name: 'MovieDetail',
  props: {
    visible: {
      type: Boolean,
      default: false
    },
    movie: {
      type: Object,
      default: null
    },
    imageMap: {
      type: Object,
      default: function () {
        return {}
      }
    },
    categories: {
      type: Array,
      default: function () {
        return []
      }
    }
  },
  data() {
    return {
      commentText: '',
      replyText: '',
      replyingId: null,
      editMode: false,
      editForm: {
        mingcheng: '',
        fenlei: [],
        daoyan: '',
        zhuyan: '',
        nianfen: '',
        pingfen: 0,
        jianjie: '',
        haibao: '',
        haibaoUrl: ''
      }
    }
  },
  computed: {
    posterSrc() {
      if (!this.movie) return ''
      if (this.movie.haibaoUrl) return this.movie.haibaoUrl
      const key = './assets/images/' + this.movie.haibao
      return this.imageMap[key] || ''
    },
    showCategories() {
      if (!this.movie) return []
      const list = this.normalizeCategory(this.movie.fenlei)
      return list.length ? list : ['未分类']
    },
    replyTotal() {
      if (!this.movie) return 0
      return this.movie.pinglun.reduce((sum, item) => sum + this.getReplyCount(item), 0)
    }
  },
  watch: {
    movie: {
      immediate: true,
      handler(movie) {
        if (!movie) return
        this.editMode = false
        this.editForm = {
          mingcheng: movie.mingcheng,
          fenlei: this.normalizeCategory(movie.fenlei),
          daoyan: movie.daoyan,
          zhuyan: movie.zhuyan,
          nianfen: movie.nianfen,
          pingfen: Number(movie.pingfen),
          jianjie: movie.jianjie,
          haibao: movie.haibao || '',
          haibaoUrl: movie.haibaoUrl || ''
        }
      }
    }
  },
  methods: {
    normalizeCategory(value) {
      if (Array.isArray(value)) return value
      if (!value) return []
      return [value]
    },
    getReplyCount(item) {
      const oldCount = Number(item.huifu || 0)
      const listCount = item.huifuList ? item.huifuList.length : 0
      return oldCount + listCount
    },
    handleError(event) {
      event.target.src = 'https://via.placeholder.com/300x420?text=Movie'
    },
    addComment() {
      const text = this.commentText.trim()
      if (!text || !this.movie) return
      this.$emit('comment', this.movie.id, text)
      this.commentText = ''
    },
    toggleReply(id) {
      this.replyingId = this.replyingId === id ? null : id
      this.replyText = ''
    },
    sendReply(commentId) {
      const text = this.replyText.trim()
      if (!text || !this.movie) return
      this.$emit('reply', this.movie.id, commentId, text)
      this.replyText = ''
      this.replyingId = null
    },
    openEdit() {
      this.editMode = true
    },
    handlePosterChange(file) {
      if (!file.raw) return
      const url = URL.createObjectURL(file.raw)
      this.editForm.haibaoUrl = url
      this.editForm.haibao = file.name
    },
    saveEdit() {
      if (!this.editForm.mingcheng) {
        alert('电影名称不能为空')
        return
      }
      this.$emit('update-movie', this.movie.id, {
        ...this.editForm,
        fenlei: this.editForm.fenlei.slice(0, 3),
        pingfen: Number(this.editForm.pingfen || 0).toFixed(1)
      })
      this.editMode = false
    },
    closeDialog() {
      this.editMode = false
      this.replyingId = null
      this.replyText = ''
      this.commentText = ''
      this.$emit('close')
    }
  }
}
</script>

<style scoped>
.detail {
  display: flex;
  gap: 24px;
}

.poster {
  width: 260px;
  height: 380px;
  object-fit: cover;
  border-radius: 14px;
  background: #ddd;
}

.content {
  flex: 1;
}

.headline {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.headline h2 {
  margin: 0;
}

.score-box {
  display: flex;
  align-items: center;
  gap: 10px;
  color: #e67e22;
  font-weight: bold;
}

.tags {
  display: flex;
  gap: 8px;
  margin: 14px 0;
  flex-wrap: wrap;
}

.line {
  display: flex;
  align-items: center;
  gap: 7px;
  color: #555;
  line-height: 1.7;
}

.intro {
  line-height: 1.9;
  color: #444;
  margin: 16px 0;
}

.detail-actions {
  margin: 12px 0 18px;
}

.comment-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.comment-title h3 {
  margin: 10px 0;
}

.dropdown-link {
  display: flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  color: #409eff;
}

.mark {
  margin-left: 22px;
}

.comment-list {
  max-height: 240px;
  overflow-y: auto;
  padding-right: 6px;
}

.comment {
  background: #f6f7f9;
  border-radius: 12px;
  padding: 10px;
  margin-bottom: 10px;
}

.comment-main {
  display: flex;
  gap: 10px;
}

.comment-body {
  flex: 1;
}

.comment-main p {
  margin: 0;
  color: #333;
  line-height: 1.6;
}

.comment-actions {
  margin-top: 4px;
}

.danger-btn {
  color: #f56c6c;
}

.reply-list {
  margin-top: 8px;
  padding-left: 8px;
  border-left: 3px solid #dcdfe6;
}

.reply-item {
  display: flex;
  align-items: center;
  gap: 6px;
  color: #666;
  font-size: 13px;
  line-height: 1.8;
}

.reply-box {
  display: flex;
  gap: 8px;
  margin-top: 8px;
}

.publish {
  display: flex;
  gap: 10px;
  margin-top: 14px;
}

.edit-panel {
  background: #f6f7f9;
  border-radius: 14px;
  padding: 16px;
  margin-bottom: 18px;
}

.edit-panel h3 {
  margin: 0 0 14px;
}

.edit-panel .el-row {
  margin-bottom: 12px;
}

.full {
  width: 100%;
}

.upload-area {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.upload-tip {
  color: #888;
  font-size: 13px;
}

.edit-buttons {
  display: flex;
  gap: 10px;
  margin-top: 12px;
}
</style>
