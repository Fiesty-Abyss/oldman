<template>
  <div class="movie-card" @click="$emit('open-detail', movie)">
    <img :src="posterSrc" @error="handleError" />

    <div class="info">
      <div class="title-line">
        <h3>{{ movie.mingcheng }}</h3>

        <div class="tag-list">
          <el-tag v-for="item in showCategories" :key="item" size="small">
            {{ item }}
          </el-tag>
        </div>
      </div>

      <p class="meta">{{ movie.nianfen }} · {{ movie.daoyan }}</p>

      <div class="actors">
        <i class="el-icon-user"></i>
        <span>{{ movie.zhuyan }}</span>
      </div>

      <p class="score">评分：{{ movie.pingfen }} / 10</p>
      <p class="desc">{{ movie.jianjie }}</p>

      <div class="badges">
        <el-badge :value="movie.pinglun.length" class="item">
          <el-button size="small">评论</el-button>
        </el-badge>

        <el-badge :value="replyTotal" class="item" type="warning">
          <el-button size="small">回复</el-button>
        </el-badge>
      </div>

      <div class="actions" @click.stop>
        <el-button size="small" type="primary" @click="$emit('edit', movie)">修改</el-button>
        <el-button size="small" type="danger" @click="$emit('delete', movie.id)">删除</el-button>
        <el-button size="small" @click="$emit('open-detail', movie)">查看详情</el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MovieCard',
  props: {
    movie: {
      type: Object,
      default: function () {
        return {}
      }
    },
    imageMap: {
      type: Object,
      default: function () {
        return {}
      }
    }
  },
  computed: {
    posterSrc() {
      if (this.movie.haibaoUrl) return this.movie.haibaoUrl
      const key = './assets/images/' + this.movie.haibao
      return this.imageMap[key] || ''
    },
    showCategories() {
      const list = Array.isArray(this.movie.fenlei)
        ? this.movie.fenlei
        : this.movie.fenlei
          ? [this.movie.fenlei]
          : []
      return list.length ? list : ['未分类']
    },
    replyTotal() {
      return this.movie.pinglun.reduce((sum, item) => {
        const oldCount = Number(item.huifu || 0)
        const listCount = item.huifuList ? item.huifuList.length : 0
        return sum + oldCount + listCount
      }, 0)
    }
  },
  methods: {
    handleError(event) {
      event.target.src = 'https://via.placeholder.com/300x420?text=Movie'
    }
  }
}
</script>

<style scoped>
.movie-card {
  display: flex;
  background: var(--card-bg);
  color: var(--text-main);
  border-radius: 18px;
  overflow: hidden;
  box-shadow: var(--shadow);
  transition: 0.2s;
  cursor: pointer;
}

.movie-card:hover {
  transform: translateY(-3px);
}

.movie-card img {
  width: 180px;
  height: 270px;
  object-fit: cover;
  background: #ddd;
}

.info {
  flex: 1;
  padding: 18px;
}

.title-line {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}

.info h3 {
  margin: 0;
  font-size: 21px;
}

.tag-list {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.meta {
  margin: 9px 0;
  color: var(--text-sub);
}

.actors {
  display: flex;
  align-items: center;
  gap: 6px;
  color: var(--text-sub);
  line-height: 1.5;
}

.score {
  color: #e67e22;
  font-weight: bold;
  margin: 10px 0;
}

.desc {
  color: var(--text-sub);
  line-height: 1.7;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
  min-height: 72px;
}

.badges {
  margin: 14px 0;
}

.item {
  margin-right: 34px;
}

.actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
