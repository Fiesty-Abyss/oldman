export const defaultCategories = [
    '科幻',
    '奇幻',
    '悬疑',
    '犯罪',
    '动作',
    '恐怖',
    '惊悚',
    '动画',
    '爱情',
    '喜剧',
    '剧情'
]

export const defaultMovies = [
    {
        id: 1,
        mingcheng: '哈利波特与魔法石',
        fenlei: ['奇幻', '剧情'],
        daoyan: '克里斯·哥伦布',
        zhuyan: '丹尼尔·雷德克里夫，艾玛·沃森，鲁伯特·格林特',
        nianfen: '2001',
        pingfen: '9.2',
        haibao: '哈利波特与魔法石.jpg',
        jianjie: '哈利波特从小寄住在姨妈家，过着被忽视的生活。十一岁生日那天，他得知自己是一名巫师，并被霍格沃茨魔法学校录取。进入学校后，他结识了罗恩和赫敏，也第一次感受到友情、归属和冒险的意义。电影用温暖又神秘的方式打开了魔法世界的大门。',
        pinglun: [
            { id: 1, neirong: '第一部的魔法感最纯粹，看完真的很想收到霍格沃茨录取通知书。', zan: 18, huifu: 2, huifuList: [] },
            { id: 2, neirong: '节奏很舒服，不急着炫世界观，而是一点点把人带进去。', zan: 11, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 2,
        mingcheng: '哈利波特与密室',
        fenlei: ['奇幻', '悬疑', '剧情'],
        daoyan: '克里斯·哥伦布',
        zhuyan: '丹尼尔·雷德克里夫，艾玛·沃森，鲁伯特·格林特',
        nianfen: '2002',
        pingfen: '8.9',
        haibao: '哈利波特与密室.jpg',
        jianjie: '哈利回到霍格沃茨后，学校里出现了密室被打开的传闻，学生接连遭到石化。随着调查深入，哈利发现自己与蛇语、斯莱特林以及伏地魔的过去产生了更深联系。相比第一部，本片氛围更阴暗，悬疑感也更明显。',
        pinglun: [
            { id: 1, neirong: '密室那种阴冷感很有记忆点，小时候看真的有点怕。', zan: 13, huifu: 3, huifuList: [] },
            { id: 2, neirong: '蛇怪和日记本的设定很精彩，悬疑味比第一部更浓。', zan: 9, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 3,
        mingcheng: '哈利波特与阿兹卡班的囚徒',
        fenlei: ['奇幻', '悬疑', '剧情'],
        daoyan: '阿方索·卡隆',
        zhuyan: '丹尼尔·雷德克里夫，加里·奥德曼，艾玛·沃森',
        nianfen: '2004',
        pingfen: '9.0',
        haibao: '哈利波特与阿兹卡班的囚徒.jpg',
        jianjie: '哈利得知阿兹卡班囚犯小天狼星越狱，而外界传闻他正是背叛哈利父母的人。随着真相慢慢揭开，哈利第一次真正接近父母过去的秘密。本片风格更成熟，时间转换器、摄魂怪、小天狼星与卢平的关系都让故事多了一层悲伤质感。',
        pinglun: [
            { id: 1, neirong: '这一部气质真的变成熟了，画面和音乐都更冷。', zan: 16, huifu: 2, huifuList: [] },
            { id: 2, neirong: '小天狼星出现后，哈利终于有了可以依靠的亲人。', zan: 14, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 4,
        mingcheng: '无间道',
        fenlei: ['犯罪', '悬疑', '剧情'],
        daoyan: '刘伟强，麦兆辉',
        zhuyan: '刘德华，梁朝伟，黄秋生，曾志伟',
        nianfen: '2002',
        pingfen: '9.3',
        haibao: '无间道.jpg',
        jianjie: '电影讲述两个身份相反的人，一个是警方卧底，一个是黑帮内鬼，他们都长期生活在伪装和压力之中。故事没有简单地把人物分成好人与坏人，而是把身份焦虑、命运拉扯和心理压迫拍得非常克制。天台对峙成为港片影史中的经典场面。',
        pinglun: [
            { id: 1, neirong: '梁朝伟那个眼神太厉害了，很多话不用说出来。', zan: 22, huifu: 5, huifuList: [] },
            { id: 2, neirong: '港片巅峰之一，节奏干净，人物也压得住。', zan: 19, huifu: 3, huifuList: [] }
        ]
    },
    {
        id: 5,
        mingcheng: '嫌疑人X的献身',
        fenlei: ['悬疑', '犯罪', '剧情'],
        daoyan: '西谷弘',
        zhuyan: '福山雅治，堤真一，松雪泰子',
        nianfen: '2008',
        pingfen: '8.4',
        haibao: '嫌疑人X的献身.jpg',
        jianjie: '石神是一位沉默寡言的数学天才，他用近乎极致的逻辑为邻居母女设计了一场难以破解的掩护。电影表面是推理，核心却是一个孤独的人如何把爱意隐藏在牺牲里。它没有把情感处理得很外放，而是越克制越让人难受。',
        pinglun: [
            { id: 1, neirong: '看完以后很久缓不过来，石神这个角色太苦了。', zan: 17, huifu: 2, huifuList: [] },
            { id: 2, neirong: '推理只是外壳，真正让人难受的是里面的感情。', zan: 13, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 6,
        mingcheng: '七宗罪',
        fenlei: ['悬疑', '犯罪', '惊悚'],
        daoyan: '大卫·芬奇',
        zhuyan: '布拉德·皮特，摩根·弗里曼，凯文·史派西',
        nianfen: '1995',
        pingfen: '8.8',
        haibao: '七宗罪.jpg',
        jianjie: '两名警探追查一系列以七宗罪为主题的连环案件。城市阴暗潮湿，人物疲惫麻木，案件本身像一场针对人性的审判。电影的压迫感并不依赖单纯的血腥，而是通过气氛、节奏和结局一步步把观众拖进绝望。',
        pinglun: [
            { id: 1, neirong: '芬奇真的太会拍阴郁城市了，看完心里堵得慌。', zan: 14, huifu: 2, huifuList: [] },
            { id: 2, neirong: '结尾冲击力太强，知道答案再重看也还是难受。', zan: 13, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 7,
        mingcheng: '速度与激情7',
        fenlei: ['动作', '犯罪'],
        daoyan: '温子仁',
        zhuyan: '范·迪塞尔，保罗·沃克，杰森·斯坦森',
        nianfen: '2015',
        pingfen: '8.4',
        haibao: '速度与激情7.jpg',
        jianjie: '这一部延续了系列的飞车、爆破和团队作战，同时因为保罗·沃克的告别而多了一层特别的情感重量。电影的动作场面很夸张，但真正留在观众心里的，是最后那段分道而行的告别。',
        pinglun: [
            { id: 1, neirong: '最后那首歌一出来真的绷不住。', zan: 21, huifu: 4, huifuList: [] },
            { id: 2, neirong: '动作很爽，但最打动人的还是家人这个主题。', zan: 13, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 8,
        mingcheng: '疾速追杀',
        fenlei: ['动作', '犯罪', '惊悚'],
        daoyan: '查德·斯塔赫斯基',
        zhuyan: '基努·里维斯，迈克尔·恩奎斯特，阿尔菲·艾伦',
        nianfen: '2014',
        pingfen: '7.8',
        haibao: '疾速追杀.jpg',
        jianjie: '约翰·威克原本已经退出杀手世界，却因为爱犬被杀、旧车被抢而重新踏入地下秩序。电影动作设计干净利落，枪战和近身格斗结合得非常流畅。它建立了一套冷酷又讲规矩的杀手世界。',
        pinglun: [
            { id: 1, neirong: '动作戏太干净了，没有多余废招。', zan: 16, huifu: 2, huifuList: [] },
            { id: 2, neirong: '地下酒店的设定很带感，世界观不复杂但很有味道。', zan: 10, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 9,
        mingcheng: '叶问',
        fenlei: ['动作', '剧情'],
        daoyan: '叶伟信',
        zhuyan: '甄子丹，任达华，熊黛林',
        nianfen: '2008',
        pingfen: '7.8',
        haibao: '叶问.jpg',
        jianjie: '影片以一代宗师叶问为核心，展现他在动荡时代中的隐忍、担当和武者气度。电影的动作设计强调力量与节奏，咏春的短打风格被表现得非常清楚。它不是单纯炫技，而是把家国、尊严和个人品格放进武打场面里。',
        pinglun: [
            { id: 1, neirong: '甄子丹打得太稳了，动作特别有节奏。', zan: 12, huifu: 1, huifuList: [] },
            { id: 2, neirong: '十个我要打十个，这段真的记得太清楚。', zan: 18, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 10,
        mingcheng: '咒',
        fenlei: ['恐怖', '惊悚'],
        daoyan: '柯孟融',
        zhuyan: '蔡亘晏，高英轩，林敬伦',
        nianfen: '2022',
        pingfen: '6.9',
        haibao: '咒.jpg',
        jianjie: '电影采用伪纪录片形式，把民俗禁忌、家庭关系和心理恐惧结合在一起。它最有效的地方是让观众产生参与感，仿佛自己也被卷入了某种不该触碰的仪式。影片的恐怖来自持续不断的暗示、污染感和后劲。',
        pinglun: [
            { id: 1, neirong: '它不是单纯吓人，是那种看完觉得身上不干净的感觉。', zan: 15, huifu: 2, huifuList: [] },
            { id: 2, neirong: '民俗恐怖拍好了真的比突然跳出来更吓人。', zan: 11, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 11,
        mingcheng: '招魂',
        fenlei: ['恐怖', '惊悚'],
        daoyan: '温子仁',
        zhuyan: '维拉·法米加，帕特里克·威尔森，莉莉·泰勒',
        nianfen: '2013',
        pingfen: '8.0',
        haibao: '招魂.jpg',
        jianjie: '沃伦夫妇受邀调查一栋发生异常现象的房子。电影将传统鬼屋、驱魔和家庭恐惧结合起来，节奏控制非常成熟。温子仁通过空间调度、声音和镜头移动制造持续紧张感。',
        pinglun: [
            { id: 1, neirong: '温子仁很会拿捏观众什么时候该紧张。', zan: 17, huifu: 2, huifuList: [] },
            { id: 2, neirong: '拍手那段真的吓得我一激灵。', zan: 14, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 12,
        mingcheng: '电锯惊魂',
        fenlei: ['恐怖', '惊悚', '悬疑'],
        daoyan: '温子仁',
        zhuyan: '雷·沃纳尔，加利·艾尔维斯，丹尼·格洛弗',
        nianfen: '2004',
        pingfen: '8.7',
        haibao: '电锯惊魂.jpg',
        jianjie: '两个陌生人在密室中醒来，被迫面对一场残酷的生存游戏。电影成本不高，却凭借极强的结构设计和结尾反转成为经典。它真正让人印象深刻的不是机关本身，而是被规则操控、被迫选择的绝望感。',
        pinglun: [
            { id: 1, neirong: '结尾真的太狠了，第一次看完全没猜到。', zan: 18, huifu: 3, huifuList: [] },
            { id: 2, neirong: '密室感和压迫感都很强，低成本能拍成这样很厉害。', zan: 11, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 13,
        mingcheng: '千与千寻',
        fenlei: ['动画', '奇幻', '剧情'],
        daoyan: '宫崎骏',
        zhuyan: '柊瑠美，入野自由，夏木真理',
        nianfen: '2001',
        pingfen: '9.4',
        haibao: '千与千寻.jpg',
        jianjie: '千寻误入神灵世界，父母变成猪，她不得不在陌生的汤屋里工作并寻找回家的办法。电影既像一场奇幻冒险，也像一个关于成长、劳动、记忆和自我名字的寓言。长大后再看，会发现它讲的不只是童话。',
        pinglun: [
            { id: 1, neirong: '小时候看热闹，长大看才发现里面全是人生。', zan: 24, huifu: 4, huifuList: [] },
            { id: 2, neirong: '白龙带千寻飞那段美得不像话。', zan: 13, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 14,
        mingcheng: '你的名字',
        fenlei: ['动画', '爱情', '奇幻'],
        daoyan: '新海诚',
        zhuyan: '神木隆之介，上白石萌音，长泽雅美',
        nianfen: '2016',
        pingfen: '8.5',
        haibao: '你的名字.jpg',
        jianjie: '住在乡下的三叶和生活在东京的泷，在梦中交换身体，并逐渐建立起一种跨越时间与空间的联系。电影将青春、遗憾、灾难和命运感结合在一起，画面明亮绚丽，音乐也极大增强了情绪。',
        pinglun: [
            { id: 1, neirong: '画面和音乐配合得太好了，情绪一下就被推起来。', zan: 17, huifu: 2, huifuList: [] },
            { id: 2, neirong: '最后擦肩而过再回头，真的很会拍。', zan: 14, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 15,
        mingcheng: '疯狂动物城',
        fenlei: ['动画', '喜剧', '爱情'],
        daoyan: '拜伦·霍华德，瑞奇·摩尔',
        zhuyan: '金妮弗·古德温，杰森·贝特曼，伊德瑞斯·艾尔巴',
        nianfen: '2016',
        pingfen: '9.2',
        haibao: '疯狂动物城.jpg',
        jianjie: '兔子朱迪怀着成为警察的梦想来到动物城，却发现这里并不像想象中那么公平。她与狐狸尼克搭档调查案件，在轻松幽默的外壳下，电影讨论了偏见、标签和社会分工。',
        pinglun: [
            { id: 1, neirong: '尼克和朱迪的搭档感很好，轻松但不幼稚。', zan: 15, huifu: 2, huifuList: [] },
            { id: 2, neirong: '树懒办事那段笑死，电影院里全场都在乐。', zan: 20, huifu: 3, huifuList: [] }
        ]
    },
    {
        id: 16,
        mingcheng: '泰坦尼克号',
        fenlei: ['爱情', '剧情'],
        daoyan: '詹姆斯·卡梅隆',
        zhuyan: '莱昂纳多·迪卡普里奥，凯特·温斯莱特，比利·赞恩',
        nianfen: '1997',
        pingfen: '9.5',
        haibao: '泰坦尼克号.jpg',
        jianjie: '杰克和露丝在泰坦尼克号上相遇，两人在阶级差异和命运阴影中相爱。电影将灾难片的宏大场面与爱情片的细腻情绪结合起来，让一段短暂的关系拥有了跨越时间的重量。',
        pinglun: [
            { id: 1, neirong: '每次重看都知道结局，但还是会被打动。', zan: 23, huifu: 5, huifuList: [] },
            { id: 2, neirong: '杰克带给露丝的不只是爱情，还有活下去的勇气。', zan: 18, huifu: 3, huifuList: [] }
        ]
    },
    {
        id: 17,
        mingcheng: '怦然心动',
        fenlei: ['爱情', '剧情', '喜剧'],
        daoyan: '罗伯·莱纳',
        zhuyan: '玛德琳·卡罗尔，卡兰·麦克奥利菲，瑞贝卡·德·莫妮',
        nianfen: '2010',
        pingfen: '9.1',
        haibao: '怦然心动.jpg',
        jianjie: '朱莉从小喜欢布莱斯，但两个人对彼此的理解一直错位。电影用双视角讲述青春期的心动、误会、自尊和成长。它没有激烈的戏剧冲突，却把年少时那种小心翼翼、骄傲又敏感的喜欢拍得很真。',
        pinglun: [
            { id: 1, neirong: '很干净的青春片，看完心里软软的。', zan: 19, huifu: 3, huifuList: [] },
            { id: 2, neirong: '朱莉真的太美好了，她的喜欢很勇敢。', zan: 15, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 18,
        mingcheng: '爱乐之城',
        fenlei: ['爱情', '剧情', '喜剧'],
        daoyan: '达米恩·查泽雷',
        zhuyan: '瑞恩·高斯林，艾玛·斯通，约翰·传奇',
        nianfen: '2016',
        pingfen: '8.4',
        haibao: '爱乐之城.jpg',
        jianjie: '米娅和塞巴斯蒂安在洛杉矶相遇，一个追逐演员梦想，一个坚持爵士乐理想。电影用歌舞片的形式讲述爱情与梦想之间的选择。它浪漫、明亮，却并不回避现实里的错过。',
        pinglun: [
            { id: 1, neirong: '结尾那段幻想太狠了，像把另一种人生快速过了一遍。', zan: 18, huifu: 2, huifuList: [] },
            { id: 2, neirong: '它不是传统圆满爱情片，但后劲很大。', zan: 13, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 19,
        mingcheng: '听见涛声',
        fenlei: ['动画', '爱情', '剧情'],
        daoyan: '望月智充',
        zhuyan: '飞田展男，坂本洋子，关俊彦',
        nianfen: '1993',
        pingfen: '8.2',
        haibao: '听见涛声.jpg',
        jianjie: '故事围绕高中时代的转学生武藤里伽子展开，男主在回忆中重新理解当年那段别扭、青涩又带着距离感的青春关系。它没有强烈的戏剧爆点，更像一封慢慢展开的旧信，里面有误会、自尊、犹豫和年少时说不清的在意。',
        pinglun: [
            { id: 1, neirong: '很淡，但淡得很真实，像回忆里突然浮起来的一阵海风。', zan: 10, huifu: 1, huifuList: [] },
            { id: 2, neirong: '不是那种大开大合的青春片，反而更像真的青春。', zan: 8, huifu: 0, huifuList: [] }
        ]
    },
    {
        id: 20,
        mingcheng: '黑社会以和为贵',
        fenlei: ['犯罪', '剧情', '惊悚'],
        daoyan: '杜琪峰',
        zhuyan: '古天乐，任达华，张家辉，林家栋',
        nianfen: '2006',
        pingfen: '8.3',
        haibao: '黑社会以和为贵.jpg',
        jianjie: '影片延续了杜琪峰对帮派秩序、权力交替和人性选择的冷峻观察。表面上是社团话事人的争夺，背后却是传统规矩与现实利益之间的撕扯。电影没有把江湖拍得浪漫，而是拍出了权力结构里的冷、狠和身不由己。',
        pinglun: [
            { id: 1, neirong: '杜琪峰的黑帮片很冷，不靠热血，靠的是压迫感。', zan: 14, huifu: 2, huifuList: [] },
            { id: 2, neirong: '古天乐这一部的变化很有层次，越看越觉得可怕。', zan: 12, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 21,
        mingcheng: '星际穿越',
        fenlei: ['科幻', '剧情', '爱情'],
        daoyan: '克里斯托弗·诺兰',
        zhuyan: '马修·麦康纳，安妮·海瑟薇，杰西卡·查斯坦',
        nianfen: '2014',
        pingfen: '9.4',
        haibao: '星际穿越.jpg',
        jianjie: '在地球环境逐渐恶化的未来，人类为了寻找新的生存希望，派出宇航员穿越虫洞探索未知星系。电影把硬科幻、亲情和时间差带来的残酷结合在一起，既有宇宙尺度的壮阔，也有父女关系里最私人的牵挂。',
        pinglun: [
            { id: 1, neirong: '玉米地和宇宙放在一起，居然能拍得这么动人。', zan: 22, huifu: 4, huifuList: [] },
            { id: 2, neirong: '不是只有科幻设定厉害，亲情部分才是最扎心的。', zan: 19, huifu: 3, huifuList: [] }
        ]
    },
    {
        id: 22,
        mingcheng: '心慌方',
        fenlei: ['科幻', '悬疑', '惊悚'],
        daoyan: '文森佐·纳塔利',
        zhuyan: '妮可·德波儿，大卫·休莱特，妮基·瓜达尼',
        nianfen: '1997',
        pingfen: '7.9',
        haibao: '心慌方.jpg',
        jianjie: '几个陌生人醒来后发现自己被困在一个由无数立方体房间组成的空间中，每个房间都可能暗藏致命机关。电影用极低成本搭建出强烈的封闭感，把生存压力、猜疑和人性崩坏压缩在狭小空间里。',
        pinglun: [
            { id: 1, neirong: '密闭空间加未知规则，压迫感一下就起来了。', zan: 13, huifu: 2, huifuList: [] },
            { id: 2, neirong: '低成本科幻惊悚能拍成这样，概念真的很聪明。', zan: 11, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 23,
        mingcheng: '午夜凶铃',
        fenlei: ['恐怖', '悬疑', '惊悚'],
        daoyan: '中田秀夫',
        zhuyan: '松岛菜菜子，真田广之，竹内结子',
        nianfen: '1998',
        pingfen: '7.6',
        haibao: '午夜凶铃.jpg',
        jianjie: '一盘看过后七天就会死亡的录像带，将记者浅川卷入一连串怪异事件。电影真正可怕的地方不是频繁惊吓，而是录像带、电话、电视机和贞子构成的日常污染感。它把都市传说拍成了现代恐怖片的经典符号。',
        pinglun: [
            { id: 1, neirong: '电视机这个意象太强了，看完很久都不敢半夜开电视。', zan: 16, huifu: 2, huifuList: [] },
            { id: 2, neirong: '日式恐怖的阴冷感真的和欧美恐怖不一样。', zan: 12, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 24,
        mingcheng: '猫鼠游戏',
        fenlei: ['犯罪', '剧情', '喜剧'],
        daoyan: '史蒂文·斯皮尔伯格',
        zhuyan: '莱昂纳多·迪卡普里奥，汤姆·汉克斯，克里斯托弗·沃肯',
        nianfen: '2002',
        pingfen: '9.1',
        haibao: '猫鼠游戏.jpg',
        jianjie: '弗兰克年纪轻轻就以高超骗术伪装成飞行员、医生和律师，而执着的探员卡尔则一路追踪。电影节奏轻快，表面是骗子与探员之间的追逐，内里却有家庭破裂后的孤独和对身份认同的渴望。',
        pinglun: [
            { id: 1, neirong: '小李子演这种聪明又脆弱的角色真的很合适。', zan: 18, huifu: 3, huifuList: [] },
            { id: 2, neirong: '节奏特别舒服，犯罪片也能拍得这么轻盈。', zan: 14, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 25,
        mingcheng: '纵横四海',
        fenlei: ['动作', '犯罪', '喜剧'],
        daoyan: '吴宇森',
        zhuyan: '周润发，张国荣，钟楚红',
        nianfen: '1991',
        pingfen: '8.8',
        haibao: '纵横四海.jpg',
        jianjie: '影片讲述三名盗贼在艺术品盗窃、友情与爱情之间周旋的故事。它有吴宇森式的浪漫动作，也有港片黄金年代特有的潇洒与轻盈。周润发、张国荣和钟楚红之间的气质太迷人，让这部电影既像犯罪片，也像一场带着笑意的旧梦。',
        pinglun: [
            { id: 1, neirong: '三个人的状态太好了，潇洒得让人移不开眼。', zan: 15, huifu: 2, huifuList: [] },
            { id: 2, neirong: '它不是那种沉重犯罪片，而是特别浪漫、特别港味。', zan: 12, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 26,
        mingcheng: '盗梦空间',
        fenlei: ['科幻', '悬疑', '动作'],
        daoyan: '克里斯托弗·诺兰',
        zhuyan: '莱昂纳多·迪卡普里奥，约瑟夫·高登-莱维特，艾伦·佩吉',
        nianfen: '2010',
        pingfen: '9.4',
        haibao: '盗梦空间.jpg',
        jianjie: '柯布是一名能够潜入他人梦境盗取秘密的高手，他接到一项几乎不可能完成的任务：不是偷走想法，而是在目标脑中植入一个念头。电影将梦境层级、时间流速和心理执念编织成一场复杂又紧张的冒险。它既有烧脑结构，也有柯布对家庭和现实的执念。',
        pinglun: [
            { id: 1, neirong: '第一次看真的被梦中梦震住了，结构太漂亮。', zan: 21, huifu: 3, huifuList: [] },
            { id: 2, neirong: '陀螺结尾太会留余味了，看完还一直想。', zan: 18, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 27,
        mingcheng: '楚门的世界',
        fenlei: ['剧情', '科幻', '喜剧'],
        daoyan: '彼得·威尔',
        zhuyan: '金·凯瑞，劳拉·琳妮，艾德·哈里斯',
        nianfen: '1998',
        pingfen: '9.3',
        haibao: '楚门的世界.jpg',
        jianjie: '楚门从出生起就生活在一场巨大真人秀中，身边的一切亲友、街道和天空都被精心设计。电影用温和甚至带点幽默的方式，讲了一个关于自由、真实和自我觉醒的故事。当楚门开始怀疑世界的边界时，观众也会跟着思考自己是否真的活在自己选择的人生里。',
        pinglun: [
            { id: 1, neirong: '表面轻松，越想越后怕，人生被安排这件事太窒息了。', zan: 20, huifu: 4, huifuList: [] },
            { id: 2, neirong: '最后推门出去那一刻真的很有力量。', zan: 17, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 28,
        mingcheng: '寄生虫',
        fenlei: ['剧情', '悬疑', '犯罪'],
        daoyan: '奉俊昊',
        zhuyan: '宋康昊，李善均，赵汝贞，崔宇植，朴素丹',
        nianfen: '2019',
        pingfen: '8.8',
        haibao: '寄生虫.jpg',
        jianjie: '贫困家庭金家人通过伪装身份逐渐进入富人朴家的生活。电影前半段像黑色喜剧，后半段却突然滑向残酷的阶级寓言。它最厉害的地方在于没有把矛盾简单归结为某个人的恶，而是通过空间、气味和身份差距，把社会结构里的不平等拍得刺痛又荒诞。',
        pinglun: [
            { id: 1, neirong: '前面还在笑，后面突然笑不出来了。', zan: 19, huifu: 3, huifuList: [] },
            { id: 2, neirong: '半地下室和豪宅的对比太狠了，空间本身就在讲故事。', zan: 15, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 29,
        mingcheng: '肖申克的救赎',
        fenlei: ['剧情', '犯罪'],
        daoyan: '弗兰克·德拉邦特',
        zhuyan: '蒂姆·罗宾斯，摩根·弗里曼，鲍勃·冈顿',
        nianfen: '1994',
        pingfen: '9.7',
        haibao: '肖申克的救赎.jpg',
        jianjie: '银行家安迪被误判入狱，在肖申克监狱中度过漫长岁月。电影讲的不是简单越狱，而是在绝望环境里如何保留尊严、希望和耐心。安迪安静、克制，却从未真正被体制驯服。那条通向自由的隧道，是他多年坚持之后终于打开的出口。',
        pinglun: [
            { id: 1, neirong: '希望这个主题太强了，看完会觉得人不能轻易认输。', zan: 28, huifu: 5, huifuList: [] },
            { id: 2, neirong: '安迪在雨里张开双臂那一幕太经典了。', zan: 23, huifu: 3, huifuList: [] }
        ]
    },
    {
        id: 30,
        mingcheng: '霸王别姬',
        fenlei: ['剧情', '爱情'],
        daoyan: '陈凯歌',
        zhuyan: '张国荣，张丰毅，巩俐',
        nianfen: '1993',
        pingfen: '9.6',
        haibao: '霸王别姬.jpg',
        jianjie: '电影围绕程蝶衣、段小楼和菊仙展开，把个人命运、戏曲人生和时代洪流交织在一起。程蝶衣一生沉入戏里，分不清台上台下，也不愿分清。影片的情感复杂而沉重，既有痴情，也有背叛，更有时代碾过个体时留下的无力感。',
        pinglun: [
            { id: 1, neirong: '张国荣的程蝶衣太绝了，像是真的从戏里走出来的人。', zan: 27, huifu: 4, huifuList: [] },
            { id: 2, neirong: '不是简单的爱情片，是一整个人生被时代撕碎。', zan: 22, huifu: 3, huifuList: [] }
        ]
    },
    {
        id: 31,
        mingcheng: '低俗小说',
        fenlei: ['犯罪', '剧情', '喜剧'],
        daoyan: '昆汀·塔伦蒂诺',
        zhuyan: '约翰·特拉沃尔塔，乌玛·瑟曼，塞缪尔·杰克逊',
        nianfen: '1994',
        pingfen: '8.9',
        haibao: '低俗小说.jpg',
        jianjie: '电影用非线性叙事串联起杀手、拳击手、黑帮老大和神秘手提箱等人物与事件。它的魅力不在于传统意义上的完整情节，而在于对话、节奏、暴力幽默和风格感。昆汀把犯罪故事拍得像一张拼贴唱片，荒诞、随性又极具辨识度。',
        pinglun: [
            { id: 1, neirong: '昆汀的对白真的有魔力，废话都能听得津津有味。', zan: 16, huifu: 2, huifuList: [] },
            { id: 2, neirong: '结构很散但一点不乱，看完反而觉得很完整。', zan: 13, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 32,
        mingcheng: '看不见的客人',
        fenlei: ['悬疑', '犯罪', '剧情'],
        daoyan: '奥里奥尔·保罗',
        zhuyan: '马里奥·卡萨斯，阿娜·瓦格纳，何塞·科罗纳多',
        nianfen: '2016',
        pingfen: '8.8',
        haibao: '看不见的客人.jpg',
        jianjie: '一名事业成功的企业家卷入密室杀人案，他请来金牌律师为自己辩护，却在不断复盘中暴露出越来越多的矛盾。电影通过反复推翻叙述制造悬念，每一次讲述都像是在改写真相。它节奏紧密，反转密集，很适合作为悬疑片入门推荐。',
        pinglun: [
            { id: 1, neirong: '反转一个接一个，但不是为了反转而反转。', zan: 18, huifu: 3, huifuList: [] },
            { id: 2, neirong: '最后真相揭开的时候很爽，前面细节都能对上。', zan: 14, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 33,
        mingcheng: '致命ID',
        fenlei: ['悬疑', '惊悚', '犯罪'],
        daoyan: '詹姆斯·曼高德',
        zhuyan: '约翰·库萨克，雷·利奥塔，阿曼达·皮特',
        nianfen: '2003',
        pingfen: '8.9',
        haibao: '致命ID.jpg',
        jianjie: '一群陌生人因暴雨被困在偏僻汽车旅馆，随后接连发生命案。电影以经典暴风雪山庄式结构开局，却在后半段逐渐揭开更深层的心理谜题。它的悬疑气氛紧绷，人物身份复杂，结尾也带有很强的冷意。',
        pinglun: [
            { id: 1, neirong: '汽车旅馆那个封闭空间太适合悬疑片了。', zan: 15, huifu: 2, huifuList: [] },
            { id: 2, neirong: '结尾挺阴的，看完还会回想前面的细节。', zan: 12, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 34,
        mingcheng: '闪灵',
        fenlei: ['恐怖', '惊悚', '剧情'],
        daoyan: '斯坦利·库布里克',
        zhuyan: '杰克·尼科尔森，谢莉·杜瓦尔，丹尼·劳埃德',
        nianfen: '1980',
        pingfen: '8.3',
        haibao: '闪灵.jpg',
        jianjie: '作家杰克带着妻儿来到山中酒店担任冬季看守，却在封闭环境和诡异力量的影响下逐渐走向疯狂。电影的恐怖不靠密集惊吓，而是靠空间、构图、音乐和人物精神崩坏制造寒意。空旷走廊、双胞胎和斧头破门都成为影史经典画面。',
        pinglun: [
            { id: 1, neirong: '库布里克拍恐怖片太冷了，那种规整构图反而更吓人。', zan: 17, huifu: 3, huifuList: [] },
            { id: 2, neirong: '杰克尼科尔森那个表情真的疯得很有压迫感。', zan: 13, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 35,
        mingcheng: '机器人总动员',
        fenlei: ['动画', '科幻', '爱情'],
        daoyan: '安德鲁·斯坦顿',
        zhuyan: '本·贝尔特，艾丽莎·奈特，杰夫·格尔林',
        nianfen: '2008',
        pingfen: '9.3',
        haibao: '机器人总动员.jpg',
        jianjie: '地球被垃圾覆盖后，小机器人瓦力独自在废墟中日复一日工作，直到探测机器人伊芙来到地球。电影前半段几乎没有对白，却用动作、眼神和声音讲出了孤独与心动。它既是科幻寓言，也是非常纯粹的爱情故事。',
        pinglun: [
            { id: 1, neirong: '瓦力和伊芙牵手那种小心翼翼的感觉太可爱了。', zan: 21, huifu: 4, huifuList: [] },
            { id: 2, neirong: '没有多少台词但情绪特别满，皮克斯真的强。', zan: 17, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 36,
        mingcheng: '飞屋环游记',
        fenlei: ['动画', '喜剧', '剧情'],
        daoyan: '彼特·道格特，鲍勃·彼德森',
        zhuyan: '爱德华·阿斯纳，乔丹·长井，克里斯托弗·普卢默',
        nianfen: '2009',
        pingfen: '9.1',
        haibao: '飞屋环游记.jpg',
        jianjie: '老人卡尔为了完成与妻子艾莉的约定，用气球带着房子飞向远方。电影开头短短几分钟就讲完一段人生，温柔又扎心。后面的冒险看似轻松热闹，实则是在讲如何告别过去、重新拥抱新的陪伴和生活。',
        pinglun: [
            { id: 1, neirong: '开头那段人生蒙太奇太狠了，每次看都想哭。', zan: 22, huifu: 5, huifuList: [] },
            { id: 2, neirong: '它不是简单冒险动画，是关于告别和继续生活。', zan: 16, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 37,
        mingcheng: '侧耳倾听',
        fenlei: ['动画', '爱情', '剧情'],
        daoyan: '近藤喜文',
        zhuyan: '本名阳子，高桥一生，立花隆',
        nianfen: '1995',
        pingfen: '8.9',
        haibao: '侧耳倾听.jpg',
        jianjie: '月岛雯是喜欢读书和写作的少女，她因为图书借阅卡上的名字注意到天泽圣司，并在相处中逐渐意识到梦想与努力的意义。电影没有夸张的冲突，却把青春期对未来的迷茫、心动和自我证明拍得很细腻。',
        pinglun: [
            { id: 1, neirong: '很温柔的一部，青春不是热血喊口号，而是慢慢找到方向。', zan: 15, huifu: 2, huifuList: [] },
            { id: 2, neirong: '看完会想认真对待自己的喜欢和梦想。', zan: 12, huifu: 1, huifuList: [] }
        ]
    },
    {
        id: 38,
        mingcheng: '情书',
        fenlei: ['爱情', '剧情'],
        daoyan: '岩井俊二',
        zhuyan: '中山美穗，丰川悦司，柏原崇',
        nianfen: '1995',
        pingfen: '8.9',
        haibao: '情书.jpg',
        jianjie: '一封寄往逝者旧地址的信，意外连接起两个长相相似的女子和一段被尘封的青春记忆。电影的情绪非常克制，雪地、图书馆、旧回忆和未说出口的喜欢共同组成了淡淡的哀伤。它讲的是怀念，也是迟来的理解。',
        pinglun: [
            { id: 1, neirong: '岩井俊二的雪景太有味道了，冷但很柔。', zan: 16, huifu: 2, huifuList: [] },
            { id: 2, neirong: '那句你好吗，真的有种穿过很多年的回声。', zan: 18, huifu: 3, huifuList: [] }
        ]
    },
    {
        id: 39,
        mingcheng: '花样年华',
        fenlei: ['爱情', '剧情'],
        daoyan: '王家卫',
        zhuyan: '梁朝伟，张曼玉，潘迪华',
        nianfen: '2000',
        pingfen: '8.8',
        haibao: '花样年华.jpg',
        jianjie: '周慕云和苏丽珍因为各自伴侣的背叛而逐渐靠近，却始终克制在礼貌、距离和沉默之中。电影的情感不靠表白，而靠走廊、旗袍、昏黄灯光和反复响起的音乐慢慢堆积。它拍的是欲言又止，也是错过本身。',
        pinglun: [
            { id: 1, neirong: '王家卫太会拍暧昧和克制了，什么都没说但什么都有。', zan: 19, huifu: 3, huifuList: [] },
            { id: 2, neirong: '张曼玉的旗袍和梁朝伟的眼神，真的绝。', zan: 17, huifu: 2, huifuList: [] }
        ]
    },
    {
        id: 40,
        mingcheng: '重庆森林',
        fenlei: ['爱情', '剧情', '犯罪'],
        daoyan: '王家卫',
        zhuyan: '林青霞，金城武，梁朝伟，王菲',
        nianfen: '1994',
        pingfen: '8.8',
        haibao: '重庆森林.jpg',
        jianjie: '电影由两个都市爱情故事组成，一个关于失恋警察与神秘女子，一个关于巡警和快餐店女孩。它没有传统爱情片的完整推进，更像一组关于孤独、错过和短暂靠近的城市切片。罐头、加州梦、狭小房间和摇晃镜头，构成了独特的王家卫气质。',
        pinglun: [
            { id: 1, neirong: '王菲那段太灵了，像一阵突然闯进生活的风。', zan: 18, huifu: 2, huifuList: [] },
            { id: 2, neirong: '很都市，很孤独，也很自由。', zan: 14, huifu: 1, huifuList: [] }
        ]
    }
]