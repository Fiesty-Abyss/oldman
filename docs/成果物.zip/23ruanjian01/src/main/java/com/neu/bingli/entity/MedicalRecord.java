package com.neu.bingli.entity;

public class MedicalRecord {
    private int id;
    private int reg_id;
    private String chief_complaint;
    private String present_illness;
    private String treat_history;
    private String past_history;
    private String allergy;
    private String physical_exam;
    private String check_advice;
    private String notice;
    private int status;

    public MedicalRecord() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getReg_id() { return reg_id; }
    public void setReg_id(int reg_id) { this.reg_id = reg_id; }
    public String getChief_complaint() { return chief_complaint; }
    public void setChief_complaint(String chief_complaint) { this.chief_complaint = chief_complaint; }
    public String getPresent_illness() { return present_illness; }
    public void setPresent_illness(String present_illness) { this.present_illness = present_illness; }
    public String getTreat_history() { return treat_history; }
    public void setTreat_history(String treat_history) { this.treat_history = treat_history; }
    public String getPast_history() { return past_history; }
    public void setPast_history(String past_history) { this.past_history = past_history; }
    public String getAllergy() { return allergy; }
    public void setAllergy(String allergy) { this.allergy = allergy; }
    public String getPhysical_exam() { return physical_exam; }
    public void setPhysical_exam(String physical_exam) { this.physical_exam = physical_exam; }
    public String getCheck_advice() { return check_advice; }
    public void setCheck_advice(String check_advice) { this.check_advice = check_advice; }
    public String getNotice() { return notice; }
    public void setNotice(String notice) { this.notice = notice; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
}
