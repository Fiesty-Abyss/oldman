package com.neu.bingli.entity;

public class MrDiagnosis {
    private int id;
    private int mr_id;
    private int diagnosis_id;
    private int diag_type;

    public MrDiagnosis() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getMr_id() { return mr_id; }
    public void setMr_id(int mr_id) { this.mr_id = mr_id; }
    public int getDiagnosis_id() { return diagnosis_id; }
    public void setDiagnosis_id(int diagnosis_id) { this.diagnosis_id = diagnosis_id; }
    public int getDiag_type() { return diag_type; }
    public void setDiag_type(int diag_type) { this.diag_type = diag_type; }
}
