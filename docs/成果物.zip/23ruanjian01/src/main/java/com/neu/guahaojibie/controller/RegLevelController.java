package com.neu.guahaojibie.controller;

import com.neu.guahaojibie.biz.RegLevelBiz;
import com.neu.guahaojibie.entity.RegLevel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("reglevel")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class RegLevelController {
    @Autowired
    private RegLevelBiz biz;

    @RequestMapping("/findAll") public List<RegLevel> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public RegLevel findById(int id) { return biz.findById(id); }
    @RequestMapping("/add") public Map<String,Object> add(RegLevel rl) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.add(rl)?1:0); m.put("msg",biz.add(rl)?"成功":"失败"); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(RegLevel rl) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(rl)?1:0); m.put("msg",biz.update(rl)?"成功":"失败"); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); m.put("msg",biz.delete(id)?"成功":"失败"); return m;
    }
}
