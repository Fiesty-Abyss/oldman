package com.neu.jiesuanleibie.entity;

public class Settlement {
    private int id;
    private String category_code;
    private String category_name;

    public Settlement() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCategory_code() { return category_code; }
    public void setCategory_code(String category_code) { this.category_code = category_code; }
    public String getCategory_name() { return category_name; }
    public void setCategory_name(String category_name) { this.category_name = category_name; }
}
