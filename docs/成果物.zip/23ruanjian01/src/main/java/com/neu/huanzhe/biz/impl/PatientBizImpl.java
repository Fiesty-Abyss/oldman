package com.neu.huanzhe.biz.impl;

import com.neu.huanzhe.biz.PatientBiz;
import com.neu.huanzhe.entity.Patient;
import com.neu.huanzhe.mapper.PatientMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("patientBiz")
public class PatientBizImpl implements PatientBiz {
    @Autowired private PatientMapper mapper;
    @Override public List<Patient> findAll() { return mapper.findAll(); }
    @Override public Patient findById(int id) { return mapper.findById(id); }
    @Override public Patient findByMedicalNo(String medical_record_no) { return mapper.findByMedicalNo(medical_record_no); }
    @Override public boolean add(Patient p) { return mapper.add(p) > 0; }
    @Override public boolean update(Patient p) { return mapper.update(p) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
}
