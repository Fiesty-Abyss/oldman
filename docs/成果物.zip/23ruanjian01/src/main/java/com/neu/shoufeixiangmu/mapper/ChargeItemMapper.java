package com.neu.shoufeixiangmu.mapper;

import com.neu.shoufeixiangmu.entity.ChargeItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface ChargeItemMapper {
    List<ChargeItem> findAll();
    ChargeItem findById(@Param("id") int id);
    List<ChargeItem> findByType(@Param("item_type") int item_type);
    int add(ChargeItem c);
    int update(ChargeItem c);
    int delete(@Param("id") int id);
}
