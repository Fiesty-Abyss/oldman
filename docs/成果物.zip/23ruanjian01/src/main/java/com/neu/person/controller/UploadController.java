package com.neu.person.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RequestMapping("upload")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class UploadController {

    @PostMapping(value = "/upload")
    public String upload(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return "上传失败,文件为空";
        }
        try {
            String filename = file.getOriginalFilename();
            System.out.println("文件名:" + filename);
            String path = "E:\\2026shixun\\uploads";
            File file1 = new File(path, filename);
            file.transferTo(file1);
            return filename;
        } catch (IOException e) {
            e.printStackTrace();
            return "上传失败:" + e.getMessage();
        }
    }
}
