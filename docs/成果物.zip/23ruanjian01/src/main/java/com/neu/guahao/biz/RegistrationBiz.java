package com.neu.guahao.biz;

import com.neu.guahao.entity.Registration;
import java.util.List;

public interface RegistrationBiz {
    List<Registration> findAll();
    Registration findById(int id);
    List<Registration> findByPatient(int patientId);
    List<Registration> findByDoctor(int doctorId);
    List<Registration> findByStatus(int status);
    boolean add(Registration r);
    boolean update(Registration r);
    boolean delete(int id);
}
