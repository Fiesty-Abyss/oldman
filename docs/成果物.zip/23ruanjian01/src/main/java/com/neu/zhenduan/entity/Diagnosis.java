package com.neu.zhenduan.entity;

public class Diagnosis {
    private int id;
    private String diag_code;
    private String diag_name;
    private String icd_code;
    private int category_id;

    public Diagnosis() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getDiag_code() { return diag_code; }
    public void setDiag_code(String diag_code) { this.diag_code = diag_code; }
    public String getDiag_name() { return diag_name; }
    public void setDiag_name(String diag_name) { this.diag_name = diag_name; }
    public String getIcd_code() { return icd_code; }
    public void setIcd_code(String icd_code) { this.icd_code = icd_code; }
    public int getCategory_id() { return category_id; }
    public void setCategory_id(int category_id) { this.category_id = category_id; }
}
