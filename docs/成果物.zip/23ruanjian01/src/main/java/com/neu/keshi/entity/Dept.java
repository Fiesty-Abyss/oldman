package com.neu.keshi.entity;

public class Dept {
    private int id;
    private String dept_code;
    private String dept_name;
    private String dept_category;
    private int dept_type;

    public Dept() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getDept_code() { return dept_code; }
    public void setDept_code(String dept_code) { this.dept_code = dept_code; }
    public String getDept_name() { return dept_name; }
    public void setDept_name(String dept_name) { this.dept_name = dept_name; }
    public String getDept_category() { return dept_category; }
    public void setDept_category(String dept_category) { this.dept_category = dept_category; }
    public int getDept_type() { return dept_type; }
    public void setDept_type(int dept_type) { this.dept_type = dept_type; }
}
