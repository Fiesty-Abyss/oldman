package com.neu.zhenduan.mapper;

import com.neu.zhenduan.entity.DiagCategory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface DiagCategoryMapper {
    List<DiagCategory> findAll();
    DiagCategory findById(@Param("id") int id);
    int add(DiagCategory dc);
    int update(DiagCategory dc);
    int delete(@Param("id") int id);
}
