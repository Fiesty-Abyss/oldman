package com.neu.user.mapper;

import com.neu.user.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {

    //登录
    public User login(@Param("uname") String uname, @Param("upwd") String upwd);

    //查询用户
    public List<User> findUser(Map<String, Object> map);

    //查询用户总数
    public int getUserCount();

    //注册用户
    public int register(User user);

    //检查用户名是否存在
    public int checkUname(String uname);

    //删除用户
    public int deleteUser(@Param("id") int id);

    //修改用户
    public int updateUser(User user);

    //按ID查用户
    public User findByUser(@Param("id") int id);
}
