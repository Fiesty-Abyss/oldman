package com.neu.chufang.entity;

import java.util.Date;

public class Prescription {
    private int id;
    private int reg_id;
    private String pres_name;
    private int pres_type;
    private int status;
    private int doctor_id;
    private Date create_time;

    public Prescription() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getReg_id() { return reg_id; }
    public void setReg_id(int reg_id) { this.reg_id = reg_id; }
    public String getPres_name() { return pres_name; }
    public void setPres_name(String pres_name) { this.pres_name = pres_name; }
    public int getPres_type() { return pres_type; }
    public void setPres_type(int pres_type) { this.pres_type = pres_type; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public int getDoctor_id() { return doctor_id; }
    public void setDoctor_id(int doctor_id) { this.doctor_id = doctor_id; }
    public Date getCreate_time() { return create_time; }
    public void setCreate_time(Date create_time) { this.create_time = create_time; }
}
