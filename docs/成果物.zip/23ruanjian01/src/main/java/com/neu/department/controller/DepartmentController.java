package com.neu.department.controller;

import com.neu.department.biz.DepartmentBiz;
import com.neu.department.entity.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("olddept")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class DepartmentController {

    @Autowired
    private DepartmentBiz departmentBiz;

    @RequestMapping(value = "/findAll")
    public List<Department> findAll() {
        return departmentBiz.findAll();
    }

    @RequestMapping(value = "/findById")
    public Department findById(int did) {
        return departmentBiz.findById(did);
    }

    @RequestMapping(value = "/addDept")
    public Map<String, Object> addDept(Department department) {
        Map<String, Object> map = new HashMap<>();
        boolean result = departmentBiz.addDept(department);
        if (result) {
            map.put("code", 1);
            map.put("msg", "添加成功");
        } else {
            map.put("code", 0);
            map.put("msg", "添加失败");
        }
        return map;
    }

    @RequestMapping(value = "/updateDept")
    public Map<String, Object> updateDept(Department department) {
        Map<String, Object> map = new HashMap<>();
        boolean result = departmentBiz.updateDept(department);
        if (result) {
            map.put("code", 1);
            map.put("msg", "修改成功");
        } else {
            map.put("code", 0);
            map.put("msg", "修改失败");
        }
        return map;
    }

    @RequestMapping(value = "/deleteDept")
    public Map<String, Object> deleteDept(int did) {
        Map<String, Object> map = new HashMap<>();
        boolean result = departmentBiz.deleteDept(did);
        if (result) {
            map.put("code", 1);
            map.put("msg", "删除成功");
        } else {
            map.put("code", 0);
            map.put("msg", "删除失败");
        }
        return map;
    }
}
