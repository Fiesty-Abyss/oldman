package com.neu.shoufei.mapper;

import com.neu.shoufei.entity.Invoice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface InvoiceMapper {
    List<Invoice> findAll();
    Invoice findById(@Param("id") int id);
    List<Invoice> findByReg(@Param("reg_id") int reg_id);
    Invoice findByNo(@Param("invoice_no") String invoice_no);
    int add(Invoice i);
    int update(Invoice i);
    int delete(@Param("id") int id);
}
