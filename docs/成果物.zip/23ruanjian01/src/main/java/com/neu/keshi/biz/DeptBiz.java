package com.neu.keshi.biz;

import com.neu.keshi.entity.Dept;
import java.util.List;

public interface DeptBiz {
    List<Dept> findAll();
    Dept findById(int id);
    boolean addDept(Dept dept);
    boolean updateDept(Dept dept);
    boolean deleteDept(int id);
}
