package com.neu.bingli.biz;

import com.neu.bingli.entity.*;
import java.util.List;

public interface MedicalBiz {
    List<MedicalRecord> findAllRecords();
    MedicalRecord findRecordById(int id);
    MedicalRecord findRecordByReg(int regId);
    boolean addRecord(MedicalRecord mr);
    boolean updateRecord(MedicalRecord mr);
    boolean deleteRecord(int id);

    List<MrDiagnosis> findDiagnosisByMr(int mrId);
    boolean addDiagnosis(MrDiagnosis md);
    boolean deleteDiagnosis(int id);
}
