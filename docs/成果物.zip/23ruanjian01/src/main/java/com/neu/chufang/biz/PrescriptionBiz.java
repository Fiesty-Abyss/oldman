package com.neu.chufang.biz;

import com.neu.chufang.entity.*;
import java.util.List;

public interface PrescriptionBiz {
    List<Prescription> findAllPres();
    Prescription findPresById(int id);
    List<Prescription> findPresByReg(int regId);
    boolean addPres(Prescription p);
    boolean updatePres(Prescription p);
    boolean deletePres(int id);

    List<PresDetail> findDetailsByPres(int presId);
    boolean addDetail(PresDetail pd);
    boolean deleteDetail(int id);
}
