package com.neu.huanzhe.biz;

import com.neu.huanzhe.entity.Patient;
import java.util.List;

public interface PatientBiz {
    List<Patient> findAll();
    Patient findById(int id);
    Patient findByMedicalNo(String medical_record_no);
    boolean add(Patient p);
    boolean update(Patient p);
    boolean delete(int id);
}
