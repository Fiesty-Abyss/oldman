package com.neu.shoufei.entity;

import java.util.Date;

public class Payment {
    private int id;
    private int reg_id;
    private Integer item_id;
    private Integer item_type;
    private double amount;
    private String pay_method;
    private Double paid_amount;
    private Double change_amount;
    private Integer operator_id;
    private Date pay_time;
    private String invoice_no;
    private int status;

    public Payment() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getReg_id() { return reg_id; }
    public void setReg_id(int reg_id) { this.reg_id = reg_id; }
    public Integer getItem_id() { return item_id; }
    public void setItem_id(Integer item_id) { this.item_id = item_id; }
    public Integer getItem_type() { return item_type; }
    public void setItem_type(Integer item_type) { this.item_type = item_type; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public String getPay_method() { return pay_method; }
    public void setPay_method(String pay_method) { this.pay_method = pay_method; }
    public Double getPaid_amount() { return paid_amount; }
    public void setPaid_amount(Double paid_amount) { this.paid_amount = paid_amount; }
    public Double getChange_amount() { return change_amount; }
    public void setChange_amount(Double change_amount) { this.change_amount = change_amount; }
    public Integer getOperator_id() { return operator_id; }
    public void setOperator_id(Integer operator_id) { this.operator_id = operator_id; }
    public Date getPay_time() { return pay_time; }
    public void setPay_time(Date pay_time) { this.pay_time = pay_time; }
    public String getInvoice_no() { return invoice_no; }
    public void setInvoice_no(String invoice_no) { this.invoice_no = invoice_no; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
}
