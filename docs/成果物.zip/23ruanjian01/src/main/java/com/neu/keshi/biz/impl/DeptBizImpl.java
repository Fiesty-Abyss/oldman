package com.neu.keshi.biz.impl;

import com.neu.keshi.biz.DeptBiz;
import com.neu.keshi.entity.Dept;
import com.neu.keshi.mapper.DeptMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("deptBiz")
public class DeptBizImpl implements DeptBiz {
    @Autowired
    private DeptMapper deptMapper;

    @Override
    public List<Dept> findAll() { return deptMapper.findAll(); }
    @Override
    public Dept findById(int id) { return deptMapper.findById(id); }
    @Override
    public boolean addDept(Dept dept) { return deptMapper.addDept(dept) > 0; }
    @Override
    public boolean updateDept(Dept dept) { return deptMapper.updateDept(dept) > 0; }
    @Override
    public boolean deleteDept(int id) { return deptMapper.deleteDept(id) > 0; }
}
