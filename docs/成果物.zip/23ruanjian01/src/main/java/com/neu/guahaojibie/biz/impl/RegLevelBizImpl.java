package com.neu.guahaojibie.biz.impl;

import com.neu.guahaojibie.biz.RegLevelBiz;
import com.neu.guahaojibie.entity.RegLevel;
import com.neu.guahaojibie.mapper.RegLevelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("regLevelBiz")
public class RegLevelBizImpl implements RegLevelBiz {
    @Autowired
    private RegLevelMapper mapper;
    @Override public List<RegLevel> findAll() { return mapper.findAll(); }
    @Override public RegLevel findById(int id) { return mapper.findById(id); }
    @Override public boolean add(RegLevel rl) { return mapper.add(rl) > 0; }
    @Override public boolean update(RegLevel rl) { return mapper.update(rl) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
}
