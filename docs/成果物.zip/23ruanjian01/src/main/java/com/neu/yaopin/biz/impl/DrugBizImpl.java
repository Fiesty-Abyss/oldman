package com.neu.yaopin.biz.impl;

import com.neu.yaopin.biz.DrugBiz;
import com.neu.yaopin.entity.Drug;
import com.neu.yaopin.mapper.DrugMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("drugBiz")
public class DrugBizImpl implements DrugBiz {
    @Autowired private DrugMapper mapper;
    @Override public List<Drug> findAll() { return mapper.findAll(); }
    @Override public Drug findById(int id) { return mapper.findById(id); }
    @Override public List<Drug> findByType(int drugType) { return mapper.findByType(drugType); }
    @Override public boolean add(Drug d) { return mapper.add(d) > 0; }
    @Override public boolean update(Drug d) { return mapper.update(d) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
}
