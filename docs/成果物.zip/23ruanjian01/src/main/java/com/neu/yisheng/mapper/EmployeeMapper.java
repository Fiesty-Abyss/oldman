package com.neu.yisheng.mapper;

import com.neu.yisheng.entity.Employee;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface EmployeeMapper {
    List<Employee> findAll();
    Employee findById(@Param("id") int id);
    List<Employee> findByDept(@Param("dept_id") int dept_id);
    List<Employee> findByRole(@Param("role_type") int role_type);
    int addEmployee(Employee emp);
    int updateEmployee(Employee emp);
    int deleteEmployee(@Param("id") int id);
}
