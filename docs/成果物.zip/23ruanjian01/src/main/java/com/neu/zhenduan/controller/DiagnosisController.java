package com.neu.zhenduan.controller;

import com.neu.zhenduan.biz.DiagnosisBiz;
import com.neu.zhenduan.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("diagnosis")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class DiagnosisController {
    @Autowired private DiagnosisBiz biz;

    // ===== 诊断分类 =====
    @RequestMapping("/category/findAll") public List<DiagCategory> findAllCategories() { return biz.findAllCategories(); }
    @RequestMapping("/category/findById") public DiagCategory findCategoryById(int id) { return biz.findCategoryById(id); }
    @RequestMapping("/category/add") public Map<String,Object> addCategory(DiagCategory dc) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.addCategory(dc)?1:0); return m;
    }
    @RequestMapping("/category/update") public Map<String,Object> updateCategory(DiagCategory dc) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.updateCategory(dc)?1:0); return m;
    }
    @RequestMapping("/category/delete") public Map<String,Object> deleteCategory(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.deleteCategory(id)?1:0); return m;
    }

    // ===== 疾病目录 =====
    @RequestMapping("/findAll") public List<Diagnosis> findAll() { return biz.findAllDiagnosis(); }
    @RequestMapping("/findById") public Diagnosis findById(int id) { return biz.findDiagnosisById(id); }
    @RequestMapping("/findByCategory") public List<Diagnosis> findByCategory(int category_id) { return biz.findDiagnosisByCategory(category_id); }
    @RequestMapping("/add") public Map<String,Object> add(Diagnosis d) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.addDiagnosis(d)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Diagnosis d) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.updateDiagnosis(d)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.deleteDiagnosis(id)?1:0); return m;
    }
}
