package com.neu.chufang.controller;

import com.neu.chufang.biz.PrescriptionBiz;
import com.neu.chufang.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("prescription")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class PrescriptionController {
    @Autowired private PrescriptionBiz biz;

    @RequestMapping("/findAll") public List<Prescription> findAll() { return biz.findAllPres(); }
    @RequestMapping("/findById") public Prescription findById(int id) { return biz.findPresById(id); }
    @RequestMapping("/findByReg") public List<Prescription> findByReg(int reg_id) { return biz.findPresByReg(reg_id); }
    @RequestMapping("/add") public Map<String,Object> add(Prescription p) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.addPres(p)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Prescription p) {
        Prescription old=biz.findPresById(p.getId());
        if(old!=null){
            if(p.getReg_id()!=0) old.setReg_id(p.getReg_id());
            if(p.getPres_name()!=null) old.setPres_name(p.getPres_name());
            if(p.getPres_type()!=0) old.setPres_type(p.getPres_type());
            if(p.getStatus()!=0) old.setStatus(p.getStatus());
            if(p.getDoctor_id()!=0) old.setDoctor_id(p.getDoctor_id());
            p=old;
        }
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.updatePres(p)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.deletePres(id)?1:0); return m;
    }
    @RequestMapping("/detail/findByPres") public List<PresDetail> findDetails(int pres_id) { return biz.findDetailsByPres(pres_id); }
    @RequestMapping("/detail/add") public Map<String,Object> addDetail(PresDetail pd) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.addDetail(pd)?1:0); return m;
    }
    @RequestMapping("/detail/delete") public Map<String,Object> deleteDetail(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.deleteDetail(id)?1:0); return m;
    }
}
