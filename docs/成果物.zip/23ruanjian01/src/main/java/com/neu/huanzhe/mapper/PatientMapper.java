package com.neu.huanzhe.mapper;

import com.neu.huanzhe.entity.Patient;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface PatientMapper {
    List<Patient> findAll();
    Patient findById(@Param("id") int id);
    Patient findByMedicalNo(@Param("medical_record_no") String medical_record_no);
    int add(Patient p);
    int update(Patient p);
    int delete(@Param("id") int id);
}
