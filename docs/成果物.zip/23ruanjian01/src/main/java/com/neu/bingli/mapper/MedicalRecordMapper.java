package com.neu.bingli.mapper;

import com.neu.bingli.entity.MedicalRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface MedicalRecordMapper {
    List<MedicalRecord> findAll();
    MedicalRecord findById(@Param("id") int id);
    MedicalRecord findByReg(@Param("reg_id") int reg_id);
    int add(MedicalRecord mr);
    int update(MedicalRecord mr);
    int delete(@Param("id") int id);
}
