package com.neu.guahao.mapper;

import com.neu.guahao.entity.Registration;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface RegistrationMapper {
    List<Registration> findAll();
    Registration findById(@Param("id") int id);
    List<Registration> findByPatient(@Param("patient_id") int patient_id);
    List<Registration> findByDoctor(@Param("doctor_id") int doctor_id);
    List<Registration> findByStatus(@Param("status") int status);
    int add(Registration r);
    int update(Registration r);
    int delete(@Param("id") int id);
}
