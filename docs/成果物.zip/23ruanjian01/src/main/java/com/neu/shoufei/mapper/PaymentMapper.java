package com.neu.shoufei.mapper;

import com.neu.shoufei.entity.Payment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface PaymentMapper {
    List<Payment> findAll();
    Payment findById(@Param("id") int id);
    List<Payment> findByReg(@Param("reg_id") int reg_id);
    int add(Payment p);
    int update(Payment p);
    int delete(@Param("id") int id);
}
