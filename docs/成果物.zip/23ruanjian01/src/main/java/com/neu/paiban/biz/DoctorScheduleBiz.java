package com.neu.paiban.biz;

import com.neu.paiban.entity.DoctorSchedule;
import java.util.List;

public interface DoctorScheduleBiz {
    List<DoctorSchedule> findAll();
    DoctorSchedule findById(int id);
    List<DoctorSchedule> findByDoctor(int doctorId);
    List<DoctorSchedule> findByDate(String workDate);
    List<DoctorSchedule> findUsable(Integer deptId, String workDate);
    boolean add(DoctorSchedule s);
    boolean update(DoctorSchedule s);
    boolean delete(int id);
    boolean addBooked(int id);
}
