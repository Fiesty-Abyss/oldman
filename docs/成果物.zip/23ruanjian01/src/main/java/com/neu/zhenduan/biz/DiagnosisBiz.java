package com.neu.zhenduan.biz;

import com.neu.zhenduan.entity.*;
import java.util.List;

public interface DiagnosisBiz {
    // 分类
    List<DiagCategory> findAllCategories();
    DiagCategory findCategoryById(int id);
    boolean addCategory(DiagCategory dc);
    boolean updateCategory(DiagCategory dc);
    boolean deleteCategory(int id);
    // 疾病
    List<Diagnosis> findAllDiagnosis();
    Diagnosis findDiagnosisById(int id);
    List<Diagnosis> findDiagnosisByCategory(int categoryId);
    boolean addDiagnosis(Diagnosis d);
    boolean updateDiagnosis(Diagnosis d);
    boolean deleteDiagnosis(int id);
}
