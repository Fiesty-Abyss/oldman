package com.neu.shoufeixiangmu.controller;

import com.neu.shoufeixiangmu.biz.ChargeItemBiz;
import com.neu.shoufeixiangmu.entity.ChargeItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("charge")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class ChargeController {
    @Autowired private ChargeItemBiz biz;
    @RequestMapping("/findAll") public List<ChargeItem> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public ChargeItem findById(int id) { return biz.findById(id); }
    @RequestMapping("/findByType") public List<ChargeItem> findByType(int item_type) { return biz.findByType(item_type); }
    @RequestMapping("/add") public Map<String,Object> add(ChargeItem c) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.add(c)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(ChargeItem c) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(c)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); return m;
    }
}
