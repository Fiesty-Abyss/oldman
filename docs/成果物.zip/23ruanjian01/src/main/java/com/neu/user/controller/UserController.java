package com.neu.user.controller;

import com.neu.user.biz.UserBiz;
import com.neu.user.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("user")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class UserController {

    @Autowired
    private UserBiz userBiz;

    @RequestMapping(value = "/login")
    //调用登录的方法
    public User login(String uname, String upwd) {
        User user = userBiz.login(uname, upwd);
        return user;
    }

    @RequestMapping(value = "/findUser")
    public Map<String, Object> findUser(Integer index) {
        if (index == null) {
            index = 1;
        }
        Map<String, Object> map = new HashMap<String, Object>();
        int size = 5;
        List<User> list = userBiz.findUser(index, size);
        int total = userBiz.getUserCount();
        map.put("list", list);
        map.put("index", index);
        map.put("total", total);
        return map;
    }

    @RequestMapping(value = "/register")
    public Map<String, Object> register(User user) {
        Map<String, Object> map = new HashMap<>();
        // 检查用户名是否已存在
        int count = userBiz.checkUname(user.getUname());
        if (count > 0) {
            map.put("code", 0);
            map.put("msg", "用户名已存在");
            return map;
        }
        // 执行注册
        boolean result = userBiz.register(user);
        if (result) {
            map.put("code", 1);
            map.put("msg", "注册成功");
        } else {
            map.put("code", 0);
            map.put("msg", "注册失败");
        }
        return map;
    }

    @RequestMapping(value = "/deleteUser")
    public Map<String, Object> deleteUser(Integer id) {
        Map<String, Object> map = new HashMap<>();
        boolean result = userBiz.deleteUser(id);
        if (result) {
            map.put("code", 1);
            map.put("msg", "删除成功");
        } else {
            map.put("code", 0);
            map.put("msg", "删除失败");
        }
        return map;
    }

    @RequestMapping(value = "/updateUser")
    public Map<String, Object> updateUser(User user) {
        Map<String, Object> map = new HashMap<>();
        boolean result = userBiz.updateUser(user);
        if (result) {
            map.put("code", 1);
            map.put("msg", "修改成功");
        } else {
            map.put("code", 0);
            map.put("msg", "修改失败");
        }
        return map;
    }

    @RequestMapping(value = "/findByUser")
    public User findByUser(Integer id) {
        User user = userBiz.findByUser(id);
        return user;
    }
}
