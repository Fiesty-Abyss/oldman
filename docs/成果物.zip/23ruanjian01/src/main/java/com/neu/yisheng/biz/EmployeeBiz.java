package com.neu.yisheng.biz;

import com.neu.yisheng.entity.Employee;
import java.util.List;

public interface EmployeeBiz {
    List<Employee> findAll();
    Employee findById(int id);
    List<Employee> findByDept(int dept_id);
    List<Employee> findByRole(int role_type);
    boolean addEmployee(Employee emp);
    boolean updateEmployee(Employee emp);
    boolean deleteEmployee(int id);
}
