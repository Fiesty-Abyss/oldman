package com.neu.keshi.mapper;

import com.neu.keshi.entity.Dept;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DeptMapper {
    List<Dept> findAll();
    Dept findById(@Param("id") int id);
    int addDept(Dept dept);
    int updateDept(Dept dept);
    int deleteDept(@Param("id") int id);
}
