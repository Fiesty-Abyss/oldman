package com.neu.shoufei.controller;

import com.neu.shenqing.biz.ApplyBiz;
import com.neu.shenqing.entity.Apply;
import com.neu.shoufei.biz.PaymentBiz;
import com.neu.shoufei.entity.*;
import com.neu.chufang.biz.PrescriptionBiz;
import com.neu.chufang.entity.Prescription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("payment")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class PaymentController {
    @Autowired private PaymentBiz biz;
    @Autowired private ApplyBiz applyBiz;
    @Autowired private PrescriptionBiz prescriptionBiz;

    @RequestMapping("/findAll") public List<Payment> findAll() { return biz.findAllPayments(); }
    @RequestMapping("/findById") public Payment findById(int id) { return biz.findPaymentById(id); }
    @RequestMapping("/findByReg") public List<Payment> findByReg(int reg_id) { return biz.findPaymentsByReg(reg_id); }
    @RequestMapping("/add") public Map<String,Object> add(Payment p) {
        boolean ok=biz.addPayment(p);
        if(ok && p.getItem_type()!=null && p.getItem_id()!=null){
            if(p.getItem_type()>=1 && p.getItem_type()<=3){
                Apply a=applyBiz.findById(p.getItem_id());
                if(a!=null){ a.setStatus(3); applyBiz.update(a); }
            }else if(p.getItem_type()==4 || p.getItem_type()==5){
                Prescription pres=prescriptionBiz.findPresById(p.getItem_id());
                if(pres!=null){ pres.setStatus(3); prescriptionBiz.updatePres(pres); }
            }
        }
        Map<String,Object> m=new HashMap<>(); m.put("code",ok?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Payment p) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.updatePayment(p)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> deletePayment(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.deletePayment(id)?1:0); return m;
    }

    @RequestMapping("/refund") public Map<String,Object> refund(int id, String refund_method, Integer operator_id) {
        Map<String,Object> m=new HashMap<>();
        Payment old=biz.findPaymentById(id);
        if(old==null){ m.put("code",0); m.put("msg","收费记录不存在"); return m; }
        if(old.getStatus()==2){ m.put("code",0); m.put("msg","该记录已退费"); return m; }
        old.setStatus(2);
        biz.updatePayment(old);

        if(old.getItem_type()!=null && old.getItem_id()!=null){
            if(old.getItem_type()>=1 && old.getItem_type()<=3){
                Apply a=applyBiz.findById(old.getItem_id());
                if(a!=null){ a.setStatus(4); applyBiz.update(a); }
            }else if(old.getItem_type()==4 || old.getItem_type()==5){
                Prescription p=prescriptionBiz.findPresById(old.getItem_id());
                if(p!=null){ p.setStatus(5); prescriptionBiz.updatePres(p); }
            }
        }

        String no="RF"+System.currentTimeMillis();
        Payment rp=new Payment();
        rp.setReg_id(old.getReg_id());
        rp.setItem_id(old.getItem_id());
        rp.setItem_type(old.getItem_type());
        rp.setAmount(0-old.getAmount());
        rp.setPay_method(refund_method==null?"现金":refund_method);
        rp.setPaid_amount(0-old.getAmount());
        rp.setChange_amount(0.0);
        rp.setOperator_id(operator_id==null?old.getOperator_id():operator_id);
        rp.setInvoice_no(no);
        rp.setStatus(2);
        boolean ok=biz.addPayment(rp);

        Invoice i=new Invoice();
        i.setInvoice_no(no);
        i.setReg_id(old.getReg_id());
        i.setAmount(0-old.getAmount());
        i.setInvoice_type(4);
        i.setOperator_id(operator_id==null || operator_id==0 ? (old.getOperator_id()==null?0:old.getOperator_id()) : operator_id);
        i.setSource_invoice_no(old.getInvoice_no());
        i.setStatus(1);
        i.setPrint_count(1);
        biz.addInvoice(i);
        m.put("code",ok?1:0);
        m.put("invoice_no",no);
        return m;
    }

    @RequestMapping("/invoice/findAll") public List<Invoice> findAllInvoices() { return biz.findAllInvoices(); }
    @RequestMapping("/invoice/findByReg") public List<Invoice> findInvoicesByReg(int reg_id) { return biz.findInvoicesByReg(reg_id); }
    @RequestMapping("/invoice/findByNo") public Invoice findInvoiceByNo(String invoice_no) { return biz.findInvoiceByNo(invoice_no); }
    @RequestMapping("/invoice/add") public Map<String,Object> addInvoice(Invoice i) {
        if(i.getStatus()==0) i.setStatus(1);
        if(i.getPrint_count()==0) i.setPrint_count(1);
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.addInvoice(i)?1:0); return m;
    }
    @RequestMapping("/invoice/reprint") public Map<String,Object> reprint(String invoice_no, Integer operator_id) {
        Map<String,Object> m=new HashMap<>();
        Invoice old=biz.findInvoiceByNo(invoice_no);
        if(old==null){ m.put("code",0); m.put("msg","发票不存在"); return m; }
        Invoice i=new Invoice();
        i.setInvoice_no(old.getInvoice_no());
        i.setReg_id(old.getReg_id());
        i.setAmount(old.getAmount());
        i.setInvoice_type(old.getInvoice_type());
        i.setOperator_id(operator_id==null?old.getOperator_id():operator_id);
        i.setSource_invoice_no(old.getInvoice_no());
        i.setStatus(3);
        i.setPrint_count(old.getPrint_count()+1);
        m.put("code",biz.addInvoice(i)?1:0);
        return m;
    }
    @RequestMapping("/invoice/rewrite") public Map<String,Object> rewrite(String invoice_no, String new_invoice_no, Integer operator_id) {
        Map<String,Object> m=new HashMap<>();
        Invoice old=biz.findInvoiceByNo(invoice_no);
        if(old==null){ m.put("code",0); m.put("msg","发票不存在"); return m; }
        old.setStatus(2);
        biz.updateInvoice(old);
        Invoice i=new Invoice();
        i.setInvoice_no(new_invoice_no==null || new_invoice_no.equals("") ? "INV"+System.currentTimeMillis() : new_invoice_no);
        i.setReg_id(old.getReg_id());
        i.setAmount(old.getAmount());
        i.setInvoice_type(old.getInvoice_type());
        i.setOperator_id(operator_id==null?old.getOperator_id():operator_id);
        i.setSource_invoice_no(old.getInvoice_no());
        i.setStatus(4);
        i.setPrint_count(1);
        m.put("code",biz.addInvoice(i)?1:0);
        m.put("invoice_no",i.getInvoice_no());
        return m;
    }
    @RequestMapping("/invoice/delete") public Map<String,Object> deleteInvoice(int id) {
        Map<String,Object> m=new HashMap<>();
        m.put("code",biz.deleteInvoice(id)?1:0);
        return m;
    }
}
