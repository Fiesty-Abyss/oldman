package com.neu.chufang.entity;

public class PresDetail {
    private int id;
    private int pres_id;
    private int drug_id;
    private String usage_method;
    private String dosage;
    private String frequency;
    private int quantity;

    public PresDetail() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getPres_id() { return pres_id; }
    public void setPres_id(int pres_id) { this.pres_id = pres_id; }
    public int getDrug_id() { return drug_id; }
    public void setDrug_id(int drug_id) { this.drug_id = drug_id; }
    public String getUsage_method() { return usage_method; }
    public void setUsage_method(String usage_method) { this.usage_method = usage_method; }
    public String getDosage() { return dosage; }
    public void setDosage(String dosage) { this.dosage = dosage; }
    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}
