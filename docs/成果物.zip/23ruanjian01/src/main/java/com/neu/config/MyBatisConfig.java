package com.neu.config;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;

@Configuration
public class MyBatisConfig {

    @Bean
    public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource);
        // XML mapper 路径
        factoryBean.setMapperLocations(
            new PathMatchingResourcePatternResolver().getResources("classpath:mapper/*.xml")
        );
        // 实体类别名包
        factoryBean.setTypeAliasesPackage(
            "com.neu.user.entity,com.neu.department.entity,com.neu.person.entity,"
            + "com.neu.keshi.entity,com.neu.yisheng.entity,com.neu.guahaojibie.entity,"
            + "com.neu.jiesuanleibie.entity,com.neu.zhenduan.entity,com.neu.shoufeixiangmu.entity,"
            + "com.neu.yaopin.entity,com.neu.huanzhe.entity,com.neu.guahao.entity,"
            + "com.neu.shoufei.entity,com.neu.bingli.entity,com.neu.shenqing.entity,"
            + "com.neu.chufang.entity,com.neu.paiban.entity"
        );
        return factoryBean.getObject();
    }

    @Bean
    public MapperScannerConfigurer mapperScannerConfigurer() {
        MapperScannerConfigurer configurer = new MapperScannerConfigurer();
        configurer.setBasePackage(
            "com.neu.user.mapper,com.neu.department.mapper,com.neu.person.mapper,"
            + "com.neu.keshi.mapper,com.neu.yisheng.mapper,com.neu.guahaojibie.mapper,"
            + "com.neu.jiesuanleibie.mapper,com.neu.zhenduan.mapper,com.neu.shoufeixiangmu.mapper,"
            + "com.neu.yaopin.mapper,com.neu.huanzhe.mapper,com.neu.guahao.mapper,"
            + "com.neu.shoufei.mapper,com.neu.bingli.mapper,com.neu.shenqing.mapper,"
            + "com.neu.chufang.mapper,com.neu.paiban.mapper"
        );
        configurer.setSqlSessionFactoryBeanName("sqlSessionFactory");
        return configurer;
    }
}
