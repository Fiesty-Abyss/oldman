package com.neu.guahao.controller;

import com.neu.guahao.biz.RegistrationBiz;
import com.neu.guahao.entity.Registration;
import com.neu.shoufei.biz.PaymentBiz;
import com.neu.shoufei.entity.Invoice;
import com.neu.shoufei.entity.Payment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("registration")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class RegistrationController {
    @Autowired private RegistrationBiz biz;
    @Autowired private PaymentBiz paymentBiz;
    @RequestMapping("/findAll") public List<Registration> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public Registration findById(int id) { return biz.findById(id); }
    @RequestMapping("/findByPatient") public List<Registration> findByPatient(int patient_id) { return biz.findByPatient(patient_id); }
    @RequestMapping("/findByDoctor") public List<Registration> findByDoctor(int doctor_id) { return biz.findByDoctor(doctor_id); }
    @RequestMapping("/findByStatus") public List<Registration> findByStatus(int status) { return biz.findByStatus(status); }
    @Transactional
    @RequestMapping("/add") public Map<String,Object> add(Registration r) {
        Map<String,Object> m=new HashMap<>();
        if(r.getInvoice_no()==null || r.getInvoice_no().equals("")) r.setInvoice_no("INV"+System.currentTimeMillis());
        boolean ok=biz.add(r);
        if(ok){
            Payment p=new Payment();
            p.setReg_id(r.getId());
            p.setAmount(r.getTotal_fee());
            p.setPay_method("现金");
            p.setPaid_amount(r.getTotal_fee());
            p.setChange_amount(0.0);
            p.setOperator_id(r.getOperator_id()==0?2:r.getOperator_id());
            p.setInvoice_no(r.getInvoice_no());
            p.setStatus(1);
            paymentBiz.addPayment(p);

            Invoice i=new Invoice();
            i.setInvoice_no(r.getInvoice_no());
            i.setReg_id(r.getId());
            i.setAmount(r.getTotal_fee());
            i.setInvoice_type(1);
            i.setOperator_id(r.getOperator_id()==0?2:r.getOperator_id());
            i.setStatus(1);
            i.setPrint_count(1);
            paymentBiz.addInvoice(i);
        }
        m.put("code",ok?1:0);
        m.put("id",r.getId());
        return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Registration r) {
        Registration old=biz.findById(r.getId());
        if(old!=null){
            if(r.getPatient_id()!=0) old.setPatient_id(r.getPatient_id());
            if(r.getReg_level_id()!=0) old.setReg_level_id(r.getReg_level_id());
            if(r.getDept_id()!=0) old.setDept_id(r.getDept_id());
            if(r.getDoctor_id()!=0) old.setDoctor_id(r.getDoctor_id());
            if(r.getSettlement_id()!=0) old.setSettlement_id(r.getSettlement_id());
            if(r.getTotal_fee()!=0) old.setTotal_fee(r.getTotal_fee());
            if(r.getStatus()!=0) old.setStatus(r.getStatus());
            if(r.getInvoice_no()!=null) old.setInvoice_no(r.getInvoice_no());
            if(r.getOperator_id()!=0) old.setOperator_id(r.getOperator_id());
            r=old;
        }
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(r)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); return m;
    }
}
