package com.neu.jiesuanleibie.mapper;

import com.neu.jiesuanleibie.entity.Settlement;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface SettlementMapper {
    List<Settlement> findAll();
    Settlement findById(@Param("id") int id);
    int add(Settlement s);
    int update(Settlement s);
    int delete(@Param("id") int id);
}
