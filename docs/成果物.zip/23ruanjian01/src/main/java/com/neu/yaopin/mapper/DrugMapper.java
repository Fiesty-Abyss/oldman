package com.neu.yaopin.mapper;

import com.neu.yaopin.entity.Drug;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface DrugMapper {
    List<Drug> findAll();
    Drug findById(@Param("id") int id);
    List<Drug> findByType(@Param("drug_type") int drug_type);
    int add(Drug d);
    int update(Drug d);
    int delete(@Param("id") int id);
}
