package com.neu.paiban.controller;

import com.neu.paiban.biz.DoctorScheduleBiz;
import com.neu.paiban.entity.DoctorSchedule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("schedule")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class DoctorScheduleController {
    @Autowired private DoctorScheduleBiz biz;

    @RequestMapping("/findAll") public List<DoctorSchedule> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public DoctorSchedule findById(int id) { return biz.findById(id); }
    @RequestMapping("/findByDoctor") public List<DoctorSchedule> findByDoctor(int doctor_id) { return biz.findByDoctor(doctor_id); }
    @RequestMapping("/findByDate") public List<DoctorSchedule> findByDate(String work_date) { return biz.findByDate(work_date); }
    @RequestMapping("/findUsable") public List<DoctorSchedule> findUsable(Integer dept_id, String work_date) { return biz.findUsable(dept_id, work_date); }
    @RequestMapping("/add") public Map<String,Object> add(DoctorSchedule s) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.add(s)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(DoctorSchedule s) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(s)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); return m;
    }
}
