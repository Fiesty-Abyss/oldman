package com.neu.department.mapper;

import com.neu.department.entity.Department;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DepartmentMapper {

    // 查询所有部门
    public List<Department> findAll();

    // 按ID查部门
    public Department findById(@Param("did") int did);

    // 新增部门
    public int addDept(Department department);

    // 修改部门
    public int updateDept(Department department);

    // 删除部门
    public int deleteDept(@Param("did") int did);
}
