package com.neu.bingli.controller;

import com.neu.bingli.biz.MedicalBiz;
import com.neu.bingli.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("medical")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class MedicalController {
    @Autowired private MedicalBiz biz;

    @RequestMapping("/findAll") public List<MedicalRecord> findAll() { return biz.findAllRecords(); }
    @RequestMapping("/findById") public MedicalRecord findById(int id) { return biz.findRecordById(id); }
    @RequestMapping("/findByReg") public MedicalRecord findByReg(int reg_id) { return biz.findRecordByReg(reg_id); }
    @RequestMapping("/add") public Map<String,Object> add(MedicalRecord mr) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.addRecord(mr)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(MedicalRecord mr) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.updateRecord(mr)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.deleteRecord(id)?1:0); return m;
    }
    @RequestMapping("/diagnosis/findByMr") public List<MrDiagnosis> findDiagByMr(int mr_id) { return biz.findDiagnosisByMr(mr_id); }
    @RequestMapping("/diagnosis/add") public Map<String,Object> addDiag(MrDiagnosis md) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.addDiagnosis(md)?1:0); return m;
    }
    @RequestMapping("/diagnosis/delete") public Map<String,Object> deleteDiag(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.deleteDiagnosis(id)?1:0); return m;
    }
}
