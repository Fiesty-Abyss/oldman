package com.neu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);

        System.out.println("==============================================");
        System.out.println("  23ruanjian01 Spring Boot 项目启动成功！");
        System.out.println("  访问地址：http://localhost:8081");
        System.out.println("==============================================");
    }
}