package com.neu.zhenduan.mapper;

import com.neu.zhenduan.entity.Diagnosis;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface DiagnosisMapper {
    List<Diagnosis> findAll();
    Diagnosis findById(@Param("id") int id);
    List<Diagnosis> findByCategory(@Param("category_id") int category_id);
    int add(Diagnosis d);
    int update(Diagnosis d);
    int delete(@Param("id") int id);
}
