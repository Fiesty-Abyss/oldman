package com.neu.shenqing.mapper;

import com.neu.shenqing.entity.Apply;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface ApplyMapper {
    List<Apply> findAll();
    Apply findById(@Param("id") int id);
    List<Apply> findByReg(@Param("reg_id") int reg_id);
    List<Apply> findByRegAndType(@Param("reg_id") int reg_id, @Param("apply_type") int apply_type);
    int add(Apply a);
    int update(Apply a);
    int delete(@Param("id") int id);
}
