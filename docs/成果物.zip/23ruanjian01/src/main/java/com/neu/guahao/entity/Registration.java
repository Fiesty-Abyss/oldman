package com.neu.guahao.entity;

import java.util.Date;

public class Registration {
    private int id;
    private int patient_id;
    private int reg_level_id;
    private int dept_id;
    private int doctor_id;
    private int settlement_id;
    private int need_book;
    private double total_fee;
    private Date reg_time;
    private int status;
    private String invoice_no;
    private int operator_id;

    public Registration() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getPatient_id() { return patient_id; }
    public void setPatient_id(int patient_id) { this.patient_id = patient_id; }
    public int getReg_level_id() { return reg_level_id; }
    public void setReg_level_id(int reg_level_id) { this.reg_level_id = reg_level_id; }
    public int getDept_id() { return dept_id; }
    public void setDept_id(int dept_id) { this.dept_id = dept_id; }
    public int getDoctor_id() { return doctor_id; }
    public void setDoctor_id(int doctor_id) { this.doctor_id = doctor_id; }
    public int getSettlement_id() { return settlement_id; }
    public void setSettlement_id(int settlement_id) { this.settlement_id = settlement_id; }
    public int getNeed_book() { return need_book; }
    public void setNeed_book(int need_book) { this.need_book = need_book; }
    public double getTotal_fee() { return total_fee; }
    public void setTotal_fee(double total_fee) { this.total_fee = total_fee; }
    public Date getReg_time() { return reg_time; }
    public void setReg_time(Date reg_time) { this.reg_time = reg_time; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public String getInvoice_no() { return invoice_no; }
    public void setInvoice_no(String invoice_no) { this.invoice_no = invoice_no; }
    public int getOperator_id() { return operator_id; }
    public void setOperator_id(int operator_id) { this.operator_id = operator_id; }
}
