package com.neu.jiesuanleibie.controller;

import com.neu.jiesuanleibie.biz.SettlementBiz;
import com.neu.jiesuanleibie.entity.Settlement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("settlement")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class SettlementController {
    @Autowired private SettlementBiz biz;
    @RequestMapping("/findAll") public List<Settlement> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public Settlement findById(int id) { return biz.findById(id); }
    @RequestMapping("/add") public Map<String,Object> add(Settlement s) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.add(s)?1:0); m.put("msg",biz.add(s)?"成功":"失败"); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Settlement s) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(s)?1:0); m.put("msg",biz.update(s)?"成功":"失败"); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); m.put("msg",biz.delete(id)?"成功":"失败"); return m;
    }
}
