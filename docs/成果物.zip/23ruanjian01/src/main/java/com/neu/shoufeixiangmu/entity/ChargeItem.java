package com.neu.shoufeixiangmu.entity;

public class ChargeItem {
    private int id;
    private String item_code;
    private String item_name;
    private String pinyin_code;
    private String spec;
    private double unit_price;
    private int item_type;
    private int dept_id;

    public ChargeItem() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getItem_code() { return item_code; }
    public void setItem_code(String item_code) { this.item_code = item_code; }
    public String getItem_name() { return item_name; }
    public void setItem_name(String item_name) { this.item_name = item_name; }
    public String getPinyin_code() { return pinyin_code; }
    public void setPinyin_code(String pinyin_code) { this.pinyin_code = pinyin_code; }
    public String getSpec() { return spec; }
    public void setSpec(String spec) { this.spec = spec; }
    public double getUnit_price() { return unit_price; }
    public void setUnit_price(double unit_price) { this.unit_price = unit_price; }
    public int getItem_type() { return item_type; }
    public void setItem_type(int item_type) { this.item_type = item_type; }
    public int getDept_id() { return dept_id; }
    public void setDept_id(int dept_id) { this.dept_id = dept_id; }
}
