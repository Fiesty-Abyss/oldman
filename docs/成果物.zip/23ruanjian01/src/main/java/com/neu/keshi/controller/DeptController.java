package com.neu.keshi.controller;

import com.neu.keshi.biz.DeptBiz;
import com.neu.keshi.entity.Dept;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("dept")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class DeptController {
    @Autowired
    private DeptBiz deptBiz;

    @RequestMapping("/findAll")
    public List<Dept> findAll() { return deptBiz.findAll(); }

    @RequestMapping("/findById")
    public Dept findById(int id) { return deptBiz.findById(id); }

    @RequestMapping("/add")
    public Map<String, Object> add(Dept dept) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", deptBiz.addDept(dept) ? 1 : 0);
        map.put("msg", deptBiz.addDept(dept) ? "添加成功" : "添加失败");
        return map;
    }

    @RequestMapping("/update")
    public Map<String, Object> update(Dept dept) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", deptBiz.updateDept(dept) ? 1 : 0);
        map.put("msg", deptBiz.updateDept(dept) ? "修改成功" : "修改失败");
        return map;
    }

    @RequestMapping("/delete")
    public Map<String, Object> delete(int id) {
        Map<String, Object> map = new HashMap<>();
        map.put("code", deptBiz.deleteDept(id) ? 1 : 0);
        map.put("msg", deptBiz.deleteDept(id) ? "删除成功" : "删除失败");
        return map;
    }
}
