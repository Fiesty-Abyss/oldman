package com.neu.shenqing.entity;

import java.util.Date;

public class Apply {
    private int id;
    private int reg_id;
    private int item_id;
    private int apply_type;
    private String check_part;
    private String purpose;
    private int is_urgent;
    private int status;
    private int doctor_id;
    private Date apply_time;
    private Date execute_time;
    private String result_text;
    private String result_image;
    private Integer tech_id;

    public Apply() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getReg_id() { return reg_id; }
    public void setReg_id(int reg_id) { this.reg_id = reg_id; }
    public int getItem_id() { return item_id; }
    public void setItem_id(int item_id) { this.item_id = item_id; }
    public int getApply_type() { return apply_type; }
    public void setApply_type(int apply_type) { this.apply_type = apply_type; }
    public String getCheck_part() { return check_part; }
    public void setCheck_part(String check_part) { this.check_part = check_part; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public int getIs_urgent() { return is_urgent; }
    public void setIs_urgent(int is_urgent) { this.is_urgent = is_urgent; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public int getDoctor_id() { return doctor_id; }
    public void setDoctor_id(int doctor_id) { this.doctor_id = doctor_id; }
    public Date getApply_time() { return apply_time; }
    public void setApply_time(Date apply_time) { this.apply_time = apply_time; }
    public Date getExecute_time() { return execute_time; }
    public void setExecute_time(Date execute_time) { this.execute_time = execute_time; }
    public String getResult_text() { return result_text; }
    public void setResult_text(String result_text) { this.result_text = result_text; }
    public String getResult_image() { return result_image; }
    public void setResult_image(String result_image) { this.result_image = result_image; }
    public Integer getTech_id() { return tech_id; }
    public void setTech_id(Integer tech_id) { this.tech_id = tech_id; }
}
