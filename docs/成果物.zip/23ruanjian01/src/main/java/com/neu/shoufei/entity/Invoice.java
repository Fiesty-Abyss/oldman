package com.neu.shoufei.entity;

import java.util.Date;

public class Invoice {
    private int id;
    private String invoice_no;
    private int reg_id;
    private double amount;
    private int invoice_type;
    private Date print_time;
    private int operator_id;
    private String source_invoice_no;
    private int status;
    private int print_count;

    public Invoice() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getInvoice_no() { return invoice_no; }
    public void setInvoice_no(String invoice_no) { this.invoice_no = invoice_no; }
    public int getReg_id() { return reg_id; }
    public void setReg_id(int reg_id) { this.reg_id = reg_id; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public int getInvoice_type() { return invoice_type; }
    public void setInvoice_type(int invoice_type) { this.invoice_type = invoice_type; }
    public Date getPrint_time() { return print_time; }
    public void setPrint_time(Date print_time) { this.print_time = print_time; }
    public int getOperator_id() { return operator_id; }
    public void setOperator_id(int operator_id) { this.operator_id = operator_id; }
    public String getSource_invoice_no() { return source_invoice_no; }
    public void setSource_invoice_no(String source_invoice_no) { this.source_invoice_no = source_invoice_no; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public int getPrint_count() { return print_count; }
    public void setPrint_count(int print_count) { this.print_count = print_count; }
}
