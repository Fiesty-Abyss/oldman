package com.neu.shoufeixiangmu.biz.impl;

import com.neu.shoufeixiangmu.biz.ChargeItemBiz;
import com.neu.shoufeixiangmu.entity.ChargeItem;
import com.neu.shoufeixiangmu.mapper.ChargeItemMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("chargeItemBiz")
public class ChargeItemBizImpl implements ChargeItemBiz {
    @Autowired private ChargeItemMapper mapper;
    @Override public List<ChargeItem> findAll() { return mapper.findAll(); }
    @Override public ChargeItem findById(int id) { return mapper.findById(id); }
    @Override public List<ChargeItem> findByType(int itemType) { return mapper.findByType(itemType); }
    @Override public boolean add(ChargeItem c) { return mapper.add(c) > 0; }
    @Override public boolean update(ChargeItem c) { return mapper.update(c) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
}
