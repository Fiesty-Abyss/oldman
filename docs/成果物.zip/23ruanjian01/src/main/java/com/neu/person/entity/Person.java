package com.neu.person.entity;

import com.neu.department.entity.Department;

import java.sql.Date;

public class Person {

    private int id;
    private String name;
    private Department dept = new Department();
    private Date time;
    private String path;

    public Person() {
    }

    public Person(int id, String name, Department dept, Date time, String path) {
        this.id = id;
        this.name = name;
        this.dept = dept;
        this.time = time;
        this.path = path;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Department getDept() {
        return dept;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
