package com.neu.jiesuanleibie.biz;

import com.neu.jiesuanleibie.entity.Settlement;
import java.util.List;

public interface SettlementBiz {
    List<Settlement> findAll();
    Settlement findById(int id);
    boolean add(Settlement s);
    boolean update(Settlement s);
    boolean delete(int id);
}
