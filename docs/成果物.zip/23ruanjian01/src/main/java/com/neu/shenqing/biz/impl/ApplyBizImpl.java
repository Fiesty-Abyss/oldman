package com.neu.shenqing.biz.impl;

import com.neu.shenqing.biz.ApplyBiz;
import com.neu.shenqing.entity.Apply;
import com.neu.shenqing.mapper.ApplyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("applyBiz")
public class ApplyBizImpl implements ApplyBiz {
    @Autowired private ApplyMapper mapper;
    @Override public List<Apply> findAll() { return mapper.findAll(); }
    @Override public Apply findById(int id) { return mapper.findById(id); }
    @Override public List<Apply> findByReg(int regId) { return mapper.findByReg(regId); }
    @Override public List<Apply> findByRegAndType(int regId, int applyType) { return mapper.findByRegAndType(regId, applyType); }
    @Override public boolean add(Apply a) { return mapper.add(a) > 0; }
    @Override public boolean update(Apply a) { return mapper.update(a) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
}
