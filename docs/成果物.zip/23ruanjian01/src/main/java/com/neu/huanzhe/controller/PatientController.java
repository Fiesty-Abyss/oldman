package com.neu.huanzhe.controller;

import com.neu.huanzhe.biz.PatientBiz;
import com.neu.huanzhe.entity.Patient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("patient")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class PatientController {
    @Autowired private PatientBiz biz;
    @RequestMapping("/findAll") public List<Patient> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public Patient findById(int id) { return biz.findById(id); }
    @RequestMapping("/findByMedicalNo") public Patient findByMedicalNo(String medical_record_no) { return biz.findByMedicalNo(medical_record_no); }
    @RequestMapping("/add") public Map<String,Object> add(Patient p) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.add(p)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Patient p) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(p)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); return m;
    }
}
