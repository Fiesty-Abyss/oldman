package com.neu.yaopin.controller;

import com.neu.yaopin.biz.DrugBiz;
import com.neu.yaopin.entity.Drug;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.*;

@RequestMapping("drug")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class DrugController {
    @Autowired private DrugBiz biz;
    @RequestMapping("/findAll") public List<Drug> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public Drug findById(int id) { return biz.findById(id); }
    @RequestMapping("/findByType") public List<Drug> findByType(int drug_type) { return biz.findByType(drug_type); }
    @RequestMapping("/add") public Map<String,Object> add(Drug d) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.add(d)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Drug d) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(d)?1:0); return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); return m;
    }
    @PostMapping("/uploadImage")
    public Map<String,Object> uploadImage(int id, MultipartFile file) {
        Map<String,Object> m=new HashMap<>();
        if(file==null||file.isEmpty()){ m.put("code",0); m.put("msg","文件为空"); return m; }
        try{
            String filename=UUID.randomUUID().toString()+"_"+file.getOriginalFilename();
            String path="E:/2026shixun/uploads/";
            new File(path).mkdirs();
            file.transferTo(new File(path+filename));
            Drug d=biz.findById(id);
            if(d!=null){ d.setImage("img/"+filename); biz.update(d); }
            m.put("code",1); m.put("msg",filename);
        }catch(IOException e){ m.put("code",0); m.put("msg","上传失败"); }
        return m;
    }
}
