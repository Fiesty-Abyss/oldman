package com.neu.guahaojibie.mapper;

import com.neu.guahaojibie.entity.RegLevel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface RegLevelMapper {
    List<RegLevel> findAll();
    RegLevel findById(@Param("id") int id);
    int add(RegLevel rl);
    int update(RegLevel rl);
    int delete(@Param("id") int id);
}
