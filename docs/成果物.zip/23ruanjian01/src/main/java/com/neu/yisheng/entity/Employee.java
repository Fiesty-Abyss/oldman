package com.neu.yisheng.entity;

public class Employee {
    private int id;
    private Integer user_id;
    private String real_name;
    private Integer dept_id;
    private Integer role_type;
    private String title;
    private int is_schedule;
    private String avatar;

    public Employee() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Integer getUser_id() { return user_id; }
    public void setUser_id(Integer user_id) { this.user_id = user_id; }
    public String getReal_name() { return real_name; }
    public void setReal_name(String real_name) { this.real_name = real_name; }
    public Integer getDept_id() { return dept_id; }
    public void setDept_id(Integer dept_id) { this.dept_id = dept_id; }
    public Integer getRole_type() { return role_type; }
    public void setRole_type(Integer role_type) { this.role_type = role_type; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public int getIs_schedule() { return is_schedule; }
    public void setIs_schedule(int is_schedule) { this.is_schedule = is_schedule; }
    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }
}
