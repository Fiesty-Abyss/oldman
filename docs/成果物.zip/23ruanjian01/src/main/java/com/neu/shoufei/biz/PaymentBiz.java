package com.neu.shoufei.biz;

import com.neu.shoufei.entity.*;
import java.util.List;

public interface PaymentBiz {
    List<Payment> findAllPayments();
    Payment findPaymentById(int id);
    List<Payment> findPaymentsByReg(int regId);
    boolean addPayment(Payment p);
    boolean updatePayment(Payment p);
    boolean deletePayment(int id);

    List<Invoice> findAllInvoices();
    Invoice findInvoiceById(int id);
    List<Invoice> findInvoicesByReg(int regId);
    Invoice findInvoiceByNo(String invoiceNo);
    boolean addInvoice(Invoice i);
    boolean updateInvoice(Invoice i);
    boolean deleteInvoice(int id);
}
