package com.neu.guahao.biz.impl;

import com.neu.guahao.biz.RegistrationBiz;
import com.neu.guahao.entity.Registration;
import com.neu.guahao.mapper.RegistrationMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("registrationBiz")
public class RegistrationBizImpl implements RegistrationBiz {
    @Autowired private RegistrationMapper mapper;
    @Override public List<Registration> findAll() { return mapper.findAll(); }
    @Override public Registration findById(int id) { return mapper.findById(id); }
    @Override public List<Registration> findByPatient(int patientId) { return mapper.findByPatient(patientId); }
    @Override public List<Registration> findByDoctor(int doctorId) { return mapper.findByDoctor(doctorId); }
    @Override public List<Registration> findByStatus(int status) { return mapper.findByStatus(status); }
    @Override public boolean add(Registration r) { return mapper.add(r) > 0; }
    @Override public boolean update(Registration r) { return mapper.update(r) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
}
