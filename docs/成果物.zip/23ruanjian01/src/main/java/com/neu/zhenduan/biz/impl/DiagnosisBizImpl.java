package com.neu.zhenduan.biz.impl;

import com.neu.zhenduan.biz.DiagnosisBiz;
import com.neu.zhenduan.entity.*;
import com.neu.zhenduan.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("diagnosisBiz")
public class DiagnosisBizImpl implements DiagnosisBiz {
    @Autowired private DiagCategoryMapper categoryMapper;
    @Autowired private DiagnosisMapper diagnosisMapper;

    @Override public List<DiagCategory> findAllCategories() { return categoryMapper.findAll(); }
    @Override public DiagCategory findCategoryById(int id) { return categoryMapper.findById(id); }
    @Override public boolean addCategory(DiagCategory dc) { return categoryMapper.add(dc) > 0; }
    @Override public boolean updateCategory(DiagCategory dc) { return categoryMapper.update(dc) > 0; }
    @Override public boolean deleteCategory(int id) { return categoryMapper.delete(id) > 0; }

    @Override public List<Diagnosis> findAllDiagnosis() { return diagnosisMapper.findAll(); }
    @Override public Diagnosis findDiagnosisById(int id) { return diagnosisMapper.findById(id); }
    @Override public List<Diagnosis> findDiagnosisByCategory(int categoryId) { return diagnosisMapper.findByCategory(categoryId); }
    @Override public boolean addDiagnosis(Diagnosis d) { return diagnosisMapper.add(d) > 0; }
    @Override public boolean updateDiagnosis(Diagnosis d) { return diagnosisMapper.update(d) > 0; }
    @Override public boolean deleteDiagnosis(int id) { return diagnosisMapper.delete(id) > 0; }
}
