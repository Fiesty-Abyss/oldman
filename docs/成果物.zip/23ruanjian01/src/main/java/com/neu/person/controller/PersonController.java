package com.neu.person.controller;

import com.neu.person.biz.PersonBiz;
import com.neu.person.entity.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("person")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class PersonController {

    @Autowired
    private PersonBiz personBiz;

    @RequestMapping(value = "/findAll")
    public List<Person> findAll() {
        return personBiz.findAll();
    }

    @RequestMapping(value = "/findPerson")
    public Map<String, Object> findPerson(Integer index) {
        if (index == null) {
            index = 1;
        }
        int size = 5;
        Map<String, Object> map = new HashMap<String, Object>();
        //调用查询的方法
        List<Person> list = personBiz.findPerson(index, size);
        int total = personBiz.getPersonCount();
        map.put("list", list);
        map.put("index", index);
        map.put("total", total);
        return map;
    }

    @RequestMapping(value = "/findById")
    public Person findById(int id) {
        return personBiz.findById(id);
    }

    @RequestMapping(value = "/addPerson")
    public Map<String, Object> addPerson(Integer id, String name, Integer dept_id, String time, String path) {
        Map<String, Object> map = new HashMap<>();
        Person person = new Person();
        if (id != null) {
            person.setId(id);
        }
        person.setName(name);
        if (dept_id != null) {
            person.getDept().setDid(dept_id);
        }
        try {
            if (time != null && !time.isEmpty()) {
                person.setTime(Date.valueOf(time));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        person.setPath(path);
        boolean result = personBiz.addPerson(person);
        if (result) {
            map.put("code", 1);
            map.put("msg", "添加成功");
        } else {
            map.put("code", 0);
            map.put("msg", "添加失败");
        }
        return map;
    }

    @RequestMapping(value = "/updatePerson")
    public Map<String, Object> updatePerson(Integer id, String name, Integer dept_id, String time, String path) {
        Map<String, Object> map = new HashMap<>();
        Person person = new Person();
        person.setId(id);
        person.setName(name);
        if (dept_id != null) {
            person.getDept().setDid(dept_id);
        }
        try {
            if (time != null && !time.isEmpty()) {
                person.setTime(Date.valueOf(time));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        person.setPath(path);
        boolean result = personBiz.updatePerson(person);
        if (result) {
            map.put("code", 1);
            map.put("msg", "修改成功");
        } else {
            map.put("code", 0);
            map.put("msg", "修改失败");
        }
        return map;
    }

    @RequestMapping(value = "/delPerson")
    public boolean delPerson(int id) {
        return personBiz.delPerson(id);
    }

    @RequestMapping(value = "/findByDeptId")
    public List<Person> findByDeptId(int dept_id) {
        return personBiz.findByDeptId(dept_id);
    }

    // 老师的方法：按姓名模糊查询人员
    @RequestMapping(value = "/findPersonMo")
    public Map<String, Object> findPersonMo(String name, Integer index) {
        if (name == null || name.isEmpty()) {
            return findPerson(index);
        }
        if (index == null) {
            index = 1;
        }
        int size = 5;
        Map<String, Object> map = new HashMap<>();
        List<Person> list = personBiz.findPersonMo(index, size, name);
        int total = personBiz.findPersonMoCount(name);
        map.put("list", list);
        map.put("index", index);
        map.put("total", total);
        return map;
    }

    @RequestMapping(value = "/searchPerson")
    public Map<String, Object> searchPerson(String keyword, Integer index) {
        if (keyword == null || keyword.isEmpty()) {
            return findPerson(index);
        }
        if (index == null) {
            index = 1;
        }
        int size = 5;
        Map<String, Object> map = new HashMap<>();
        List<Person> list = personBiz.searchPerson(keyword, index, size);
        int total = personBiz.searchPersonCount(keyword);
        map.put("list", list);
        map.put("index", index);
        map.put("total", total);
        return map;
    }
}
