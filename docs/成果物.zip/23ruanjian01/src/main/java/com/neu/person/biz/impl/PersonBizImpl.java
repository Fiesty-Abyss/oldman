package com.neu.person.biz.impl;

import com.neu.person.biz.PersonBiz;
import com.neu.person.entity.Person;
import com.neu.person.mapper.PersonMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("personBiz")
public class PersonBizImpl implements PersonBiz {

    @Autowired
    private PersonMapper personMapper;

    @Override
    public List<Person> findAll() {
        return personMapper.findAll();
    }

    @Override
    public List<Person> findPerson(int index, int size) {
        Map<String, Object> map = new HashMap<>();
        int index1 = (index - 1) * size;
        map.put("index", index1);
        map.put("size", size);
        List<Person> list = personMapper.findPerson(map);
        return list;
    }

    @Override
    public int getPersonCount() {
        return personMapper.getPersonCount();
    }

    @Override
    public Person findById(int id) {
        return personMapper.findById(id);
    }

    @Override
    public boolean addPerson(Person person) {
        return personMapper.addPerson(person) > 0;
    }

    @Override
    public boolean updatePerson(Person person) {
        return personMapper.updatePerson(person) > 0;
    }

    @Override
    public boolean delPerson(int id) {
        return personMapper.delPerson(id) > 0;
    }

    @Override
    public List<Person> findByDeptId(int dept_id) {
        return personMapper.findByDeptId(dept_id);
    }

    @Override
    public List<Person> searchPerson(String keyword, int index, int size) {
        Map<String, Object> map = new HashMap<>();
        int start = (index - 1) * size;
        map.put("keyword", keyword);
        map.put("index", start);
        map.put("size", size);
        return personMapper.searchPerson(map);
    }

    @Override
    public int searchPersonCount(String keyword) {
        return personMapper.searchPersonCount(keyword);
    }

    @Override
    public List<Person> findPersonMo(int index, int size, String name) {
        Map<String, Object> map = new HashMap<>();
        int start = (index - 1) * size;
        map.put("name", name);
        map.put("index", start);
        map.put("size", size);
        return personMapper.findPersonMo(map);
    }

    @Override
    public int findPersonMoCount(String name) {
        return personMapper.findPersonMoCount(name);
    }
}
