package com.neu.department.biz.impl;

import com.neu.department.biz.DepartmentBiz;
import com.neu.department.entity.Department;
import com.neu.department.mapper.DepartmentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("departmentBiz")
public class DepartmentBizImpl implements DepartmentBiz {

    @Autowired
    private DepartmentMapper departmentMapper;

    @Override
    public List<Department> findAll() {
        return departmentMapper.findAll();
    }

    @Override
    public Department findById(int did) {
        return departmentMapper.findById(did);
    }

    @Override
    public boolean addDept(Department department) {
        return departmentMapper.addDept(department) > 0;
    }

    @Override
    public boolean updateDept(Department department) {
        return departmentMapper.updateDept(department) > 0;
    }

    @Override
    public boolean deleteDept(int did) {
        return departmentMapper.deleteDept(did) > 0;
    }
}
