package com.neu.user.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("hello")
@Controller
public class HelloController {

    @RequestMapping("/hello")
    // http://localhost:8090/hello/hello
    public String hello() {
        return "hello";
    }
}
