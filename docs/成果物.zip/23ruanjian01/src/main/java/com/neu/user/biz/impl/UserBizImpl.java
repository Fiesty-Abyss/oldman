package com.neu.user.biz.impl;

import com.neu.user.biz.UserBiz;
import com.neu.user.entity.User;
import com.neu.user.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("userBiz")
public class UserBizImpl implements UserBiz {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User login(String uname, String upwd) {
        return userMapper.login(uname, upwd);
    }

    @Override
    public List<User> findUser(int index, int size) {
        Map<String, Object> map = new HashMap<>();
        map.put("index", (index - 1) * size);
        map.put("size", size);
        return userMapper.findUser(map);
    }

    @Override
    public int getUserCount() {
        return userMapper.getUserCount();
    }

    @Override
    public boolean register(User user) {
        return userMapper.register(user) > 0;
    }

    @Override
    public int checkUname(String uname) {
        return userMapper.checkUname(uname);
    }

    @Override
    public boolean deleteUser(int id) {
        return userMapper.deleteUser(id) > 0;
    }

    @Override
    public boolean updateUser(User user) {
        return userMapper.updateUser(user) > 0;
    }

    @Override
    public User findByUser(int id) {
        return userMapper.findByUser(id);
    }
}
