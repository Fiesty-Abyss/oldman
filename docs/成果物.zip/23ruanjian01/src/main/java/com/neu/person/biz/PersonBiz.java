package com.neu.person.biz;

import com.neu.person.entity.Person;

import java.util.List;

public interface PersonBiz {

    public List<Person> findAll();

    public List<Person> findPerson(int index, int size);

    public int getPersonCount();

    public Person findById(int id);

    public boolean addPerson(Person person);

    public boolean updatePerson(Person person);

    public boolean delPerson(int id);

    public List<Person> findByDeptId(int dept_id);

    public List<Person> searchPerson(String keyword, int index, int size);

    public int searchPersonCount(String keyword);

    // 老师的方法：按姓名模糊查询人员（分页）
    public List<Person> findPersonMo(int index, int size, String name);

    // 老师的方法：模糊查询结果总数
    public int findPersonMoCount(String name);
}
