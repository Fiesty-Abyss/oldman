package com.neu.chufang.mapper;

import com.neu.chufang.entity.PresDetail;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface PresDetailMapper {
    List<PresDetail> findByPres(@Param("pres_id") int pres_id);
    int add(PresDetail pd);
    int delete(@Param("id") int id);
    int deleteByPres(@Param("pres_id") int pres_id);
}
