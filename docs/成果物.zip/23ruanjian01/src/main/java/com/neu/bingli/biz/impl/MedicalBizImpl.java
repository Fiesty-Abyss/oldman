package com.neu.bingli.biz.impl;

import com.neu.bingli.biz.MedicalBiz;
import com.neu.bingli.entity.*;
import com.neu.bingli.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("medicalBiz")
public class MedicalBizImpl implements MedicalBiz {
    @Autowired private MedicalRecordMapper recordMapper;
    @Autowired private MrDiagnosisMapper diagMapper;

    @Override public List<MedicalRecord> findAllRecords() { return recordMapper.findAll(); }
    @Override public MedicalRecord findRecordById(int id) { return recordMapper.findById(id); }
    @Override public MedicalRecord findRecordByReg(int regId) { return recordMapper.findByReg(regId); }
    @Override public boolean addRecord(MedicalRecord mr) { return recordMapper.add(mr) > 0; }
    @Override public boolean updateRecord(MedicalRecord mr) { return recordMapper.update(mr) > 0; }
    @Override public boolean deleteRecord(int id) { return recordMapper.delete(id) > 0; }

    @Override public List<MrDiagnosis> findDiagnosisByMr(int mrId) { return diagMapper.findByMr(mrId); }
    @Override public boolean addDiagnosis(MrDiagnosis md) { return diagMapper.add(md) > 0; }
    @Override public boolean deleteDiagnosis(int id) { return diagMapper.delete(id) > 0; }
}
