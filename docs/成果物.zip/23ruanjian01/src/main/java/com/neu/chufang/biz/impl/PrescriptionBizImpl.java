package com.neu.chufang.biz.impl;

import com.neu.chufang.biz.PrescriptionBiz;
import com.neu.chufang.entity.*;
import com.neu.chufang.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("prescriptionBiz")
public class PrescriptionBizImpl implements PrescriptionBiz {
    @Autowired private PrescriptionMapper presMapper;
    @Autowired private PresDetailMapper detailMapper;

    @Override public List<Prescription> findAllPres() { return presMapper.findAll(); }
    @Override public Prescription findPresById(int id) { return presMapper.findById(id); }
    @Override public List<Prescription> findPresByReg(int regId) { return presMapper.findByReg(regId); }
    @Override public boolean addPres(Prescription p) { return presMapper.add(p) > 0; }
    @Override public boolean updatePres(Prescription p) { return presMapper.update(p) > 0; }
    @Override public boolean deletePres(int id) { return presMapper.delete(id) > 0; }

    @Override public List<PresDetail> findDetailsByPres(int presId) { return detailMapper.findByPres(presId); }
    @Override public boolean addDetail(PresDetail pd) { return detailMapper.add(pd) > 0; }
    @Override public boolean deleteDetail(int id) { return detailMapper.delete(id) > 0; }
}
