package com.neu.yisheng.controller;

import com.neu.yisheng.biz.EmployeeBiz;
import com.neu.yisheng.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.*;

@RequestMapping("employee")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class EmployeeController {
    @Autowired
    private EmployeeBiz employeeBiz;

    @RequestMapping("/findAll")
    public List<Employee> findAll() { return employeeBiz.findAll(); }

    @RequestMapping("/findById")
    public Employee findById(int id) { return employeeBiz.findById(id); }

    @RequestMapping("/findByDept")
    public List<Employee> findByDept(int dept_id) { return employeeBiz.findByDept(dept_id); }

    @RequestMapping("/findByRole")
    public List<Employee> findByRole(int role_type) { return employeeBiz.findByRole(role_type); }

    @RequestMapping("/add")
    public Map<String, Object> add(Employee emp) {
        Map<String, Object> map = new HashMap<>();
        boolean result = employeeBiz.addEmployee(emp);
        map.put("code", result ? 1 : 0);
        map.put("msg", result ? "添加成功" : "添加失败");
        return map;
    }

    @RequestMapping("/update")
    public Map<String, Object> update(Employee emp) {
        Map<String, Object> map = new HashMap<>();
        boolean result = employeeBiz.updateEmployee(emp);
        map.put("code", result ? 1 : 0);
        map.put("msg", result ? "修改成功" : "修改失败");
        return map;
    }

    @RequestMapping("/delete")
    public Map<String, Object> delete(int id) {
        Map<String, Object> map = new HashMap<>();
        boolean result = employeeBiz.deleteEmployee(id);
        map.put("code", result ? 1 : 0);
        map.put("msg", result ? "删除成功" : "删除失败");
        return map;
    }

    @PostMapping("/uploadAvatar")
    public Map<String, Object> uploadAvatar(int id, MultipartFile file) {
        Map<String, Object> map = new HashMap<>();
        if (file == null || file.isEmpty()) {
            map.put("code", 0);
            map.put("msg", "文件为空");
            return map;
        }
        try {
            String filename = UUID.randomUUID().toString() + "_" + file.getOriginalFilename();
            String path = "E:/2026shixun/uploads/";
            File dir = new File(path);
            if (!dir.exists()) dir.mkdirs();
            file.transferTo(new File(dir, filename));
            Employee emp = employeeBiz.findById(id);
            if (emp != null) {
                emp.setAvatar("img/" + filename);
                employeeBiz.updateEmployee(emp);
            }
            map.put("code", 1);
            map.put("msg", filename);
        } catch (IOException e) {
            map.put("code", 0);
            map.put("msg", "上传失败: " + e.getMessage());
        }
        return map;
    }
}
