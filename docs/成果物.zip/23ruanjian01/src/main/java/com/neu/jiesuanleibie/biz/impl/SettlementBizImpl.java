package com.neu.jiesuanleibie.biz.impl;

import com.neu.jiesuanleibie.biz.SettlementBiz;
import com.neu.jiesuanleibie.entity.Settlement;
import com.neu.jiesuanleibie.mapper.SettlementMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("settlementBiz")
public class SettlementBizImpl implements SettlementBiz {
    @Autowired private SettlementMapper mapper;
    @Override public List<Settlement> findAll() { return mapper.findAll(); }
    @Override public Settlement findById(int id) { return mapper.findById(id); }
    @Override public boolean add(Settlement s) { return mapper.add(s) > 0; }
    @Override public boolean update(Settlement s) { return mapper.update(s) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
}
