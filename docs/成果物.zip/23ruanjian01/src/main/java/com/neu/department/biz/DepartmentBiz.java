package com.neu.department.biz;

import com.neu.department.entity.Department;

import java.util.List;

public interface DepartmentBiz {

    public List<Department> findAll();

    public Department findById(int did);

    public boolean addDept(Department department);

    public boolean updateDept(Department department);

    public boolean deleteDept(int did);
}
