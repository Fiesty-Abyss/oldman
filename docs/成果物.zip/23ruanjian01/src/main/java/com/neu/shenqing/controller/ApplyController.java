package com.neu.shenqing.controller;

import com.neu.shenqing.biz.ApplyBiz;
import com.neu.shenqing.entity.Apply;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RequestMapping("apply")
@RestController
@CrossOrigin(origins = "http://localhost:8090", maxAge = 3600)
public class ApplyController {
    @Autowired private ApplyBiz biz;
    @RequestMapping("/findAll") public List<Apply> findAll() { return biz.findAll(); }
    @RequestMapping("/findById") public Apply findById(int id) { return biz.findById(id); }
    @RequestMapping("/findByReg") public List<Apply> findByReg(int reg_id) { return biz.findByReg(reg_id); }
    @RequestMapping("/findByRegAndType") public List<Apply> findByRegAndType(int reg_id, int apply_type) { return biz.findByRegAndType(reg_id, apply_type); }
    @RequestMapping("/add") public Map<String,Object> add(Apply a) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.add(a)?1:0); return m;
    }
    @RequestMapping("/update") public Map<String,Object> update(Apply a) {
        Apply old=biz.findById(a.getId());
        if(old!=null){
            if(a.getReg_id()!=0) old.setReg_id(a.getReg_id());
            if(a.getItem_id()!=0) old.setItem_id(a.getItem_id());
            if(a.getApply_type()!=0) old.setApply_type(a.getApply_type());
            if(a.getCheck_part()!=null) old.setCheck_part(a.getCheck_part());
            if(a.getPurpose()!=null) old.setPurpose(a.getPurpose());
            if(a.getStatus()!=0) old.setStatus(a.getStatus());
            if(a.getDoctor_id()!=0) old.setDoctor_id(a.getDoctor_id());
            if(a.getExecute_time()!=null) old.setExecute_time(a.getExecute_time());
            if(a.getResult_text()!=null) old.setResult_text(a.getResult_text());
            if(a.getResult_image()!=null) old.setResult_image(a.getResult_image());
            if(a.getTech_id()!=null) old.setTech_id(a.getTech_id());
            old.setIs_urgent(a.getIs_urgent());
            a=old;
        }
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.update(a)?1:0); return m;
    }
    @RequestMapping("/finish") public Map<String,Object> finish(int id, String result_text, String result_image, Integer tech_id) {
        Map<String,Object> m=new HashMap<>();
        Apply a=biz.findById(id);
        if(a==null){ m.put("code",0); m.put("msg","申请不存在"); return m; }
        a.setStatus(5);
        a.setResult_text(result_text);
        a.setResult_image(result_image);
        a.setTech_id(tech_id);
        a.setExecute_time(new Date());
        m.put("code",biz.update(a)?1:0);
        return m;
    }
    @RequestMapping("/delete") public Map<String,Object> delete(int id) {
        Map<String,Object> m=new HashMap<>(); m.put("code",biz.delete(id)?1:0); return m;
    }
}
