package com.neu.person.mapper;

import com.neu.person.entity.Person;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface PersonMapper {

    // 查询所有人员
    public List<Person> findAll();

    // 分页查询人员
    public List<Person> findPerson(Map<String, Object> map);

    // 查询人员总数
    public int getPersonCount();

    // 按ID查人员
    public Person findById(@Param("id") int id);

    // 新增人员
    public int addPerson(Person person);

    // 修改人员
    public int updatePerson(Person person);

    // 删除人员
    public int delPerson(@Param("id") int id);

    // 按部门ID查询人员
    public List<Person> findByDeptId(@Param("dept_id") int dept_id);

    // 模糊搜索人员（分页）
    public List<Person> searchPerson(Map<String, Object> map);

    // 模糊搜索结果总数
    public int searchPersonCount(@Param("keyword") String keyword);

    // 老师的方法：按姓名模糊查询人员（分页）
    public List<Person> findPersonMo(Map<String, Object> map);

    // 老师的方法：模糊查询结果总数
    public int findPersonMoCount(@Param("name") String name);
}
