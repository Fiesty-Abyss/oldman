package com.neu.yisheng.biz.impl;

import com.neu.yisheng.biz.EmployeeBiz;
import com.neu.yisheng.entity.Employee;
import com.neu.yisheng.mapper.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("employeeBiz")
public class EmployeeBizImpl implements EmployeeBiz {
    @Autowired
    private EmployeeMapper employeeMapper;
    @Override
    public List<Employee> findAll() { return employeeMapper.findAll(); }
    @Override
    public Employee findById(int id) { return employeeMapper.findById(id); }
    @Override
    public List<Employee> findByDept(int dept_id) { return employeeMapper.findByDept(dept_id); }
    @Override
    public List<Employee> findByRole(int role_type) { return employeeMapper.findByRole(role_type); }
    @Override
    public boolean addEmployee(Employee emp) { return employeeMapper.addEmployee(emp) > 0; }
    @Override
    public boolean updateEmployee(Employee emp) { return employeeMapper.updateEmployee(emp) > 0; }
    @Override
    public boolean deleteEmployee(int id) { return employeeMapper.deleteEmployee(id) > 0; }
}
