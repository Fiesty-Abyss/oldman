package com.neu.guahaojibie.entity;

public class RegLevel {
    private int id;
    private String reg_code;
    private String reg_name;
    private int max_count;
    private int sort_order;
    private double reg_fee;

    public RegLevel() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getReg_code() { return reg_code; }
    public void setReg_code(String reg_code) { this.reg_code = reg_code; }
    public String getReg_name() { return reg_name; }
    public void setReg_name(String reg_name) { this.reg_name = reg_name; }
    public int getMax_count() { return max_count; }
    public void setMax_count(int max_count) { this.max_count = max_count; }
    public int getSort_order() { return sort_order; }
    public void setSort_order(int sort_order) { this.sort_order = sort_order; }
    public double getReg_fee() { return reg_fee; }
    public void setReg_fee(double reg_fee) { this.reg_fee = reg_fee; }
}
