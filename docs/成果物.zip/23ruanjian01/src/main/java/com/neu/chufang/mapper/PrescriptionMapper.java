package com.neu.chufang.mapper;

import com.neu.chufang.entity.Prescription;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface PrescriptionMapper {
    List<Prescription> findAll();
    Prescription findById(@Param("id") int id);
    List<Prescription> findByReg(@Param("reg_id") int reg_id);
    int add(Prescription p);
    int update(Prescription p);
    int delete(@Param("id") int id);
}
