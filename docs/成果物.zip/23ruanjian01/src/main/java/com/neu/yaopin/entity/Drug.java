package com.neu.yaopin.entity;

public class Drug {
    private int id;
    private String drug_code;
    private String drug_name;
    private String pinyin_code;
    private String spec;
    private String dosage_form;
    private String pack_unit;
    private double unit_price;
    private int drug_type;
    private String image;

    public Drug() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getDrug_code() { return drug_code; }
    public void setDrug_code(String drug_code) { this.drug_code = drug_code; }
    public String getDrug_name() { return drug_name; }
    public void setDrug_name(String drug_name) { this.drug_name = drug_name; }
    public String getPinyin_code() { return pinyin_code; }
    public void setPinyin_code(String pinyin_code) { this.pinyin_code = pinyin_code; }
    public String getSpec() { return spec; }
    public void setSpec(String spec) { this.spec = spec; }
    public String getDosage_form() { return dosage_form; }
    public void setDosage_form(String dosage_form) { this.dosage_form = dosage_form; }
    public String getPack_unit() { return pack_unit; }
    public void setPack_unit(String pack_unit) { this.pack_unit = pack_unit; }
    public double getUnit_price() { return unit_price; }
    public void setUnit_price(double unit_price) { this.unit_price = unit_price; }
    public int getDrug_type() { return drug_type; }
    public void setDrug_type(int drug_type) { this.drug_type = drug_type; }
    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }
}
