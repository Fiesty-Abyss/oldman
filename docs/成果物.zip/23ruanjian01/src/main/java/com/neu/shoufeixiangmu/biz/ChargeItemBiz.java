package com.neu.shoufeixiangmu.biz;

import com.neu.shoufeixiangmu.entity.ChargeItem;
import java.util.List;

public interface ChargeItemBiz {
    List<ChargeItem> findAll();
    ChargeItem findById(int id);
    List<ChargeItem> findByType(int itemType);
    boolean add(ChargeItem c);
    boolean update(ChargeItem c);
    boolean delete(int id);
}
