package com.neu.user.biz;

import com.neu.user.entity.User;

import java.util.List;
import java.util.Map;

public interface UserBiz {

    public User login(String uname, String upwd);

    public List<User> findUser(int index, int size);

    public int getUserCount();

    public boolean register(User user);

    public int checkUname(String uname);

    public boolean deleteUser(int id);

    public boolean updateUser(User user);

    public User findByUser(int id);
}
