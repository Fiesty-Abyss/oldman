package com.neu.paiban.entity;

import org.springframework.format.annotation.DateTimeFormat;
import java.util.Date;

public class DoctorSchedule {
    private int id;
    private int doctor_id;
    private int dept_id;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date work_date;
    private int noon_type;
    private Integer reg_level_id;
    private int limit_count;
    private int booked_count;
    private int status;
    private String remark;

    public DoctorSchedule() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getDoctor_id() { return doctor_id; }
    public void setDoctor_id(int doctor_id) { this.doctor_id = doctor_id; }
    public int getDept_id() { return dept_id; }
    public void setDept_id(int dept_id) { this.dept_id = dept_id; }
    public Date getWork_date() { return work_date; }
    public void setWork_date(Date work_date) { this.work_date = work_date; }
    public int getNoon_type() { return noon_type; }
    public void setNoon_type(int noon_type) { this.noon_type = noon_type; }
    public Integer getReg_level_id() { return reg_level_id; }
    public void setReg_level_id(Integer reg_level_id) { this.reg_level_id = reg_level_id; }
    public int getLimit_count() { return limit_count; }
    public void setLimit_count(int limit_count) { this.limit_count = limit_count; }
    public int getBooked_count() { return booked_count; }
    public void setBooked_count(int booked_count) { this.booked_count = booked_count; }
    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }
}
