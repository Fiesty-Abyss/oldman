package com.neu.guahaojibie.biz;

import com.neu.guahaojibie.entity.RegLevel;
import java.util.List;

public interface RegLevelBiz {
    List<RegLevel> findAll();
    RegLevel findById(int id);
    boolean add(RegLevel rl);
    boolean update(RegLevel rl);
    boolean delete(int id);
}
