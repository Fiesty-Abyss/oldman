package com.neu.yaopin.biz;

import com.neu.yaopin.entity.Drug;
import java.util.List;

public interface DrugBiz {
    List<Drug> findAll();
    Drug findById(int id);
    List<Drug> findByType(int drugType);
    boolean add(Drug d);
    boolean update(Drug d);
    boolean delete(int id);
}
