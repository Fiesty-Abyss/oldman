package com.neu.paiban.mapper;

import com.neu.paiban.entity.DoctorSchedule;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface DoctorScheduleMapper {
    List<DoctorSchedule> findAll();
    DoctorSchedule findById(@Param("id") int id);
    List<DoctorSchedule> findByDoctor(@Param("doctor_id") int doctor_id);
    List<DoctorSchedule> findByDate(@Param("work_date") String work_date);
    List<DoctorSchedule> findUsable(@Param("dept_id") Integer dept_id, @Param("work_date") String work_date);
    int add(DoctorSchedule s);
    int update(DoctorSchedule s);
    int delete(@Param("id") int id);
    int addBooked(@Param("id") int id);
}
