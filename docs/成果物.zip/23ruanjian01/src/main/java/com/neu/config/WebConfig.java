package com.neu.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Spring MVC CORS 跨域配置
 * 替代自定义 CORSFilter，使用 Spring 原生机制更加可靠
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")                          // 允许所有路径
                .allowedOriginPatterns("*")                  // 允许所有来源（使用 patterns 支持 allowCredentials）
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH")
                .allowedHeaders("*")                         // 允许所有请求头
                .exposedHeaders("Authorization", "X-Token")  // 暴露自定义响应头（按需添加）
                .allowCredentials(true)                      // 允许携带 Cookie/认证信息
                .maxAge(3600);                               // 预检请求缓存 1 小时
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 将 /img/** 映射到独立上传目录，避免上传文件触发 Vue dev server 热重载
        registry.addResourceHandler("/img/**")
                .addResourceLocations("file:E:/2026shixun/uploads/");
    }
}
