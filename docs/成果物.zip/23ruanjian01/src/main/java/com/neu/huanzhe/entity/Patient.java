package com.neu.huanzhe.entity;

public class Patient {
    private int id;
    private String medical_record_no;
    private String name;
    private int gender;
    private int age;
    private String birthday;
    private String id_card;
    private String address;

    public Patient() {}
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getMedical_record_no() { return medical_record_no; }
    public void setMedical_record_no(String medical_record_no) { this.medical_record_no = medical_record_no; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getGender() { return gender; }
    public void setGender(int gender) { this.gender = gender; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getBirthday() { return birthday; }
    public void setBirthday(String birthday) { this.birthday = birthday; }
    public String getId_card() { return id_card; }
    public void setId_card(String id_card) { this.id_card = id_card; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
}
