package com.neu.paiban.biz.impl;

import com.neu.paiban.biz.DoctorScheduleBiz;
import com.neu.paiban.entity.DoctorSchedule;
import com.neu.paiban.mapper.DoctorScheduleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("doctorScheduleBiz")
public class DoctorScheduleBizImpl implements DoctorScheduleBiz {
    @Autowired private DoctorScheduleMapper mapper;
    @Override public List<DoctorSchedule> findAll() { return mapper.findAll(); }
    @Override public DoctorSchedule findById(int id) { return mapper.findById(id); }
    @Override public List<DoctorSchedule> findByDoctor(int doctorId) { return mapper.findByDoctor(doctorId); }
    @Override public List<DoctorSchedule> findByDate(String workDate) { return mapper.findByDate(workDate); }
    @Override public List<DoctorSchedule> findUsable(Integer deptId, String workDate) { return mapper.findUsable(deptId, workDate); }
    @Override public boolean add(DoctorSchedule s) { return mapper.add(s) > 0; }
    @Override public boolean update(DoctorSchedule s) { return mapper.update(s) > 0; }
    @Override public boolean delete(int id) { return mapper.delete(id) > 0; }
    @Override public boolean addBooked(int id) { return mapper.addBooked(id) > 0; }
}
