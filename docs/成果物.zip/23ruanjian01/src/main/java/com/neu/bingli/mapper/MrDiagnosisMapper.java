package com.neu.bingli.mapper;

import com.neu.bingli.entity.MrDiagnosis;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface MrDiagnosisMapper {
    List<MrDiagnosis> findByMr(@Param("mr_id") int mr_id);
    int add(MrDiagnosis md);
    int delete(@Param("id") int id);
    int deleteByMr(@Param("mr_id") int mr_id);
}
