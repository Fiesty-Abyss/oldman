package com.neu.shenqing.biz;

import com.neu.shenqing.entity.Apply;
import java.util.List;

public interface ApplyBiz {
    List<Apply> findAll();
    Apply findById(int id);
    List<Apply> findByReg(int regId);
    List<Apply> findByRegAndType(int regId, int applyType);
    boolean add(Apply a);
    boolean update(Apply a);
    boolean delete(int id);
}
