package com.neu.shoufei.biz.impl;

import com.neu.shoufei.biz.PaymentBiz;
import com.neu.shoufei.entity.*;
import com.neu.shoufei.mapper.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("paymentBiz")
public class PaymentBizImpl implements PaymentBiz {
    @Autowired private PaymentMapper paymentMapper;
    @Autowired private InvoiceMapper invoiceMapper;

    @Override public List<Payment> findAllPayments() { return paymentMapper.findAll(); }
    @Override public Payment findPaymentById(int id) { return paymentMapper.findById(id); }
    @Override public List<Payment> findPaymentsByReg(int regId) { return paymentMapper.findByReg(regId); }
    @Override public boolean addPayment(Payment p) { return paymentMapper.add(p) > 0; }
    @Override public boolean updatePayment(Payment p) { return paymentMapper.update(p) > 0; }
    @Override public boolean deletePayment(int id) { return paymentMapper.delete(id) > 0; }

    @Override public List<Invoice> findAllInvoices() { return invoiceMapper.findAll(); }
    @Override public Invoice findInvoiceById(int id) { return invoiceMapper.findById(id); }
    @Override public List<Invoice> findInvoicesByReg(int regId) { return invoiceMapper.findByReg(regId); }
    @Override public Invoice findInvoiceByNo(String invoiceNo) { return invoiceMapper.findByNo(invoiceNo); }
    @Override public boolean addInvoice(Invoice i) { return invoiceMapper.add(i) > 0; }
    @Override public boolean updateInvoice(Invoice i) { return invoiceMapper.update(i) > 0; }
    @Override public boolean deleteInvoice(int id) { return invoiceMapper.delete(id) > 0; }
}
